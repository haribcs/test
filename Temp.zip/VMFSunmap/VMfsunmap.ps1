Import-Module VMware.PowerCLI
Set-PowerCLIConfiguration -Scope Session -WebOperationTimeoutSeconds -1 -Confirm:$false
Connect-VIServer Dstravce9001,pmplavvc9100 -Credential (Get-Credential)
cd D:\CloudOps\VMFSunmap

$report = @()
$Fail = @()
[int]$i = 1
$datastores = Get-Datastore (Get-Content .\Datastore.txt)
##$datastores = Get-Datastore | where {($_.Type -EQ "VMFS")  -and ($_.ExtensionData.Info.Vmfs.Extent.DiskName -like "naa.60060e80075001000030500100*")}
foreach ($DS in $datastores){
Write-Host "Working on $i of $($datastores.count)"
$data = "" | select DSName,LunID,CapacityTB,NoOfMin,Vcenter
$data.DSName = $ds.Name
$data.LunID = $ds.ExtensionData.Info.Vmfs.Extent.Diskname
$data.CapacityTB = [math]::Round($ds.CapacityGB/1024)
$data.Vcenter = $ds.Uid.split(�:�)[0].Split("@")[1]
$data | ft -AutoSize
$esxcli = Get-EsxCli -VMHost ($ds | Get-VMHost -State Connected,Maintenance | select -First 1) -v2
$arg = @{
volumelabel = $ds.Name
reclaimunit = 800
}
Write-Host "Unmapping $($ds.name)" -ForegroundColor Yellow
$start = Get-Date
$esxcli.storage.vmfs.unmap.Invoke($arg)
$end = Get-Date
$timespan = New-TimeSpan -Start $start -End $end
$data.NoOfMin = '{0:n2}' -f $timespan.TotalMinutes
Write-Host "Script ran for $($data.NoOfMin) Minutes" -ForegroundColor Yellow
$report += $data
$data | Export-Csv .\Data.csv -UseCulture -NoTypeInformation -Append
$i += 1
}

$report | Export-Csv .\Completed.csv -UseCulture -NoTypeInformation
#$Fail | Export-Csv .\failed.csv -UseCulture -NoTypeInformation