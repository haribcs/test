$host.ui.RawUI.WindowTitle = �SHK01MPB0�
Import-Module VMware.PowerCLI,Posh-SSH
$cred = Get-Credential
Set-PowerCLIConfiguration -Scope Session -WebOperationTimeoutSeconds -1 -Confirm:$false
Connect-VIServer jvcewvvc9702,mvcewvvc9701 -user j719374@dsglobal.org -password o7aGu4wIT8QMQgKO
cd D:\CloudOps\VMFSunmap\SHK01MPB0

$report = @()
$Fail = @()
[int]$i = 1
$datastores = Get-Datastore (Get-Content .\Datastore.txt)
##$datastores = Get-Datastore | where {($_.Type -EQ "VMFS")  -and ($_.ExtensionData.Info.Vmfs.Extent.DiskName -like "naa.60060e80075001000030500100*")}
foreach ($DS in $datastores){
Write-Host "Working on $i of $($datastores.count)"
$data = "" | select DSName,LunID,CapacityTB,NoOfMin,StartTime,Endtime,Esx,Vcenter
$data.DSName = $ds.Name
$data.LunID = $ds.ExtensionData.Info.Vmfs.Extent.Diskname
$data.CapacityTB = [math]::Round($ds.CapacityGB/1024)
$data.Vcenter = $ds.Uid.split(�:�)[0].Split("@")[1]
$data | ft -AutoSize
$esx = $ds | Get-VMHost -State Connected,Maintenance | get-random
$data.esx = $esx.Name
$esx | Get-VMHostService | where key -EQ 'Tsm-ssh' | Start-VMHostService
$session = New-SSHSession -ComputerName $esx.name -Credential $cred -AcceptKey

Write-Host "Unmap is running $($ds.name)" -ForegroundColor Yellow
$start = Get-Date
$starttime = Get-Date -format "dd-MMM-yyyy HH:mm"
$data.Starttime = $starttime


Invoke-SSHCommand -Command "esxcli storage vmfs unmap -l '$ds' -n 800" -SSHSession $session -TimeOut 13600
Remove-SSHSession -SSHSession $session
$end = Get-Date
$endtime = Get-Date -format "dd-MMM-yyyy HH:mm"
$data.endtime = $endtime
$timespan = New-TimeSpan -Start $start -End $end
$data.NoOfMin = '{0:n2}' -f $timespan.TotalMinutes
cls
Write-Host "Script ran for $($data.NoOfMin) Minutes" -ForegroundColor Yellow
$report += $data
$data | Export-Csv .\Data.csv -UseCulture -NoTypeInformation -Append
$i += 1
}

$report | Export-Csv .\Completed.csv -UseCulture -NoTypeInformation
#$Fail | Export-Csv .\failed.csv -UseCulture -NoTypeInformation