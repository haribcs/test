﻿foreach ($Temp in (Get-TagAssignment -Category BackupServiceLevel | where Tag -Match CSBL)){

if(Get-TagAssignment -Category MetalTier -Entity $Temp.Entity){}else{

Switch($Temp.Tag){
{$_ -match "Gold"} {New-TagAssignment -Tag (Get-Tag -Category Metaltier -Name Gold) -Entity $temp.Entity }
{$_ -match "Platinum"} {New-TagAssignment -Tag (Get-Tag -Category Metaltier -Name Platinum) -Entity $temp.Entity}
{$_ -match "Bronze"} {New-TagAssignment -Tag (Get-Tag -Category Metaltier -Name Bronze) -Entity $temp.Entity}
{$_ -match "Silver"} {New-TagAssignment -Tag (Get-Tag -Category Metaltier -Name Silver) -Entity $temp.Entity}

}


}


}