﻿Import-Module Cisco.IMC
$report = @()
$cred = Get-Credential
cd D:\CloudOps\CIMCLocalHDD
foreach ($imc in (Get-Content .\file.txt)){

Connect-Imc $imc -Credential $cred -ErrorAction SilentlyContinue | Out-Null
Write-host "Connected"$imc
$data = Get-ImcMemoryArray | select Imc,Populated,NumOfFailedDimms,NumOfIgnoredDimms

if(($data.NumOfFailedDimms -ne 0 ) -or ($data.NumOfIgnoredDimms -ne 0)){
$report += $data
$data | ft -AutoSize
}
Disconnect-Imc | Out-Null
}
$report | export-csv .\MemoryArray.csv -UseCulture -NoTypeInformation