﻿Import-Module Cisco.IMC
$report = @()
$cred = Get-Credential
cd D:\CloudOps\CIMCLocalHDD
foreach ($imc in (Get-Content .\file.txt)){

Connect-Imc $imc -Credential $cred -ErrorAction SilentlyContinue | Out-Null
#Write-host "Connected"$imc
$data = Get-ImcStorageFlexFlashPhysicalDrive | select Imc,PdStatus,PhysicalDrive
$data | ft -AutoSize
$report += $data
Disconnect-Imc | Out-Null
}
$report | export-csv .\FlexSD.csv -UseCulture -NoTypeInformation