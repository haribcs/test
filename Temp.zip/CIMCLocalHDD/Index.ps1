﻿Import-Module Cisco.IMC
$report = @()
#$cred = Get-Credential
cd D:\CloudOps\CIMCLocalHDD
foreach ($imc in (Get-Content .\file.txt)){

Connect-Imc $imc -Credential $cred | Out-Null
$data = Get-ImcStorageFlexFlashVirtualDrive | select Imc,VirtualDrive,HostAccessible,Rn,Size
$data | ft -AutoSize
$report += $data
Disconnect-Imc | Out-Null
}
$report | export-csv .\HDDlist.csv -UseCulture -NoTypeInformation