﻿Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Confirm:$false | Out-Null
Import-Module VMware.PowerCLI,ImportExcel | Out-Null
cd D:\CloudOps\TagInventory

$password = Get-Content .\pass.txt | ConvertTo-SecureString -Key (Get-Content .\aes.key)
$credential = New-Object System.Management.Automation.PsCredential("Dsglobal.org\S705979",$password)

$filename = get-date -format yyyy-MM-ddTHH-mm-ss
$SourceExcel = "D:\CloudOps\TagInventory\TagInventory-$filename.xlsx"
$to = @("Ravindran, R. (Rajesh) <Rajesh.Ravindran@voya.com>")
$cc = @("DL-Cloud-Ops@voya.com")
$start = Get-Date


Import-Module VMware.PowerCLI

$report = @()
$vminfo = @()
$vcenters = @()
#$vcenters = "pjaxavvc9100"
$vcenters = "Mvcewvvc9701","Jvcewvvc9702","dstravce9001","astravce9001"
Foreach ($vcenter in $vcenters){
Connect-VIServer $vcenter -Credential $credential
foreach ($Temp in (Get-TagAssignment -Category BackupServiceLevel)){
$data = "" | select Tag,VMName,Powerstate,vmhost,UsedspaceTB,Cluster,Datastore,Vcenter

$data.Tag = $Temp.Tag
$data.VMName = $Temp.Entity.Name
$data.vmhost = $temp.Entity.VMHost
$data.Powerstate = $Temp.Entity.PowerState
$data.usedspaceTB =[Math]::Round($Temp.Entity.UsedSpaceGB/1024,2)
$data.Cluster = (Get-VMHost -Name $Temp.Entity.VMHost).Parent
$data.Vcenter = $vcenter
$data.Datastore = ($temp.Entity | Get-Datastore).Name -join ','
$data | ft -AutoSize
$report += $data 
}
foreach ($esxi in (Get-VMHost -State Connected)){
$new = $esxi | Get-VM | select Name,PowerState,VMHost,@{N='Cluster';E={$esxi.parent}}
$vminfo += $new

}
$global:DefaultVIServers | % { Disconnect-VIServer $_ -Confirm:$false }
}
$end = Get-Date

$Time = New-TimeSpan -Start $start -End $end
$Info = "VMware Tags Inventory `n Regards, `n Cloud Ops Team"
$report | Export-Excel -Path $SourceExcel -WorksheetName "TagsDetails" -AutoFilter
$vminfo | Export-Excel -Path $SourceExcel -WorksheetName "VMDetails" -AutoFilter
$file = Get-ChildItem | where {$_.Name -match "$filename.xlsx"}
Send-MailMessage -To hari.subramanian@voya.com -From "TagsInventory@voya.com" -Subject "Tags Inventory $filename" -Attachments $file -Body "Weekly BackUp Tags Report `n $time" -SmtpServer smtp1.dsglobal.org
