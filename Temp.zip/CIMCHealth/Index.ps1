﻿cd D:\CloudOps\CIMCHealth
Import-Module Cisco.IMC
$report = @()
$cred = Get-Credential
foreach ($imc in (Get-Content .\hosts.txt)){
Connect-Imc $imc -Credential $cred | out-null
$temp = Get-ImcStatus
$data = Get-ImcFault | Select-Object AffectedDN,Descr,Rn,@{N='CIMC';E={$imc}},@{N='Model';E={$temp.Model}},@{N='Serial';E={$temp.Serial}}
$report += $data
Disconnect-Imc | out-null
$data
}
$report | Export-Csv .\Re.csv -UseCulture -NoTypeInformation