Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Confirm:$false | Out-Null
Import-Module VMware.PowerCLI,ImportExcel | Out-Null
cd D:\CloudOps\HostGroup

$password = Get-Content .\pass.txt | ConvertTo-SecureString -Key (Get-Content .\aes.key)
$credential = New-Object System.Management.Automation.PsCredential("Dsglobal.org\S705979",$password)
$report = @()
$filename = get-date -format yyyy-MM-ddTHH-mm-ss
$SourceExcel = "D:\CloudOps\Hostgroup\Hostgroup-$filename.xlsx"
$to = @("SAN Admin <SanAdmin@voya.com>")
$cc = @("DL-Cloud-Ops@voya.com")
Connect-VIServer mvcewvvc9701,jvcewvvc9702,astravce9001,dstravce9001 -Credential $credential

foreach ($Esx in (get-cluster "SHK DB2 CLUSTER" |Get-VMHost) ){
$data = $esx | Get-VMHostHBA -Type FibreChannel |where Status -eq Online  | Select VMHost,Device,@{N="WWNN";E={"{0:X}" -f $_.NodeWorldWideName}},@{N="WWPN";E={"{0:X}" -f $_.PortWorldWideName}},@{N='Cluster';E={$esx.Parent}},@{N='Vcenter';E={$_.uid.split('@')[1].split(':')[0]}} | Sort VMhost,Device
$data | ft -AutoSize
$report += $data
}
$cluster = Get-Cluster | Select-Object Name,@{N='Host Count';E={$_.extensionData.host.count}},@{N='Vcenter';E={$_.uid.split('@')[1].split(':')[0]}}
$global:DefaultVIServers | % {Disconnect-VIServer $_ -Confirm:$false}
$report | Export-Excel -Path $SourceExcel -WorksheetName "HostGroup" -AutoFilter -AutoSize
$cluster | Export-Excel -Path $SourceExcel -WorksheetName "Cluster Info" -AutoSize -AutoFilter
$file = Get-ChildItem | where {$_.Name -match "$filename.xlsx"}
$body = "Hi Storage team `n`nPlease find the Esxi WWN and Cluster details,Kindly Update your host group based on the esxi details. `n`n CloudOps Team "
Send-MailMessage -To Hari.subramanian@voya.com -From "EsxiHostgroup@voya.com" -Subject "Weekly Host group details" -Attachments $file -SmtpServer smtp1.dsglobal.org
sleep -Seconds 200