﻿
foreach ($ds in (Get-DatastoreCluster PSTRDBCL_G15K2_SNAP | Get-Datastore)){
Write-Host "Working on $ds" -ForegroundColor Green
$datastore = New-Object VMware.Vim.ManagedObjectReference
$datastore.Type = 'Datastore'
$datastore.Value = $ds.ExtensionData.MoRef.Value
$_this = Get-View -Id 'HostDatastoreSystem-datastoreSystem-881037'
write-host "removing datastore $ds" -ForegroundColor Yellow
$_this.RemoveDatastore($datastore)

}