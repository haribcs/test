﻿$allHosts = @()
$rescanHosts = @()
Get-ChildItem -Filter vmhost.txt | Remove-Item -Confirm:$false
$lunNames = Get-Content -Path .\lunnames.txt
$AllDS = Get-Datastore | where	{$_.type -eq 'vmfs'}
    foreach($ds in ($AllDS | where { $lunNames -contains $_.ExtensionData.Info.Vmfs.Extent[0].DiskName}))
	{
        $canonicalName = $ds.ExtensionData.Info.Vmfs.Extent[0].DiskName
		$attachedHosts = $ds.ExtensionData.Host
		Write-Host "`n There are"($ds.ExtensionData.Host).count "Esxi Hosts connected to $ds" -ForegroundColor Magenta
		foreach ($vmhost in $ds.ExtensionData.Host){
				$hostview = Get-View $VMHost.Key
		$Hostname = Get-VMHost | where {$vmhost.key.value -contains $_.ExtensionData.moref.value} | Select Name
		$allHosts += $Hostname.name
		$storSys = Get-View $hostview.ConfigManager.StorageSystem
        $device = $storsys.StorageDeviceInfo.ScsiLun | where {$_.CanonicalName -eq $canonicalName}
		#$device
       if($device.OperationalState[0] -eq 'ok'){
        # unmount disk
        	Write-Host "`n Unmounting the "$ds "from" $Hostname.Name -ForegroundColor Yellow
			$StorSys.UnmountVmfsVolume($ds.ExtensionData.Info.Vmfs.Uuid)
        }
        # Detach disk
		Write-Host "`n Detaching the "$ds "from" $Hostname.Name -ForegroundColor Yellow
        $storSys.DetachScsiLun($device.Uuid)
		$allHosts | Select -Unique | Out-File .\vmhost.txt -Force
    }
}
$rescanHosts = $allHosts | Select -Unique
foreach ($temp in $rescanHosts){
Write-Host "Rescanning the HBA to commit the changes on" $temp
Get-VMHostStorage -VMHost $temp -RescanAllHba | Out-Null
}

