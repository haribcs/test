﻿#----------------- Start of code capture -----------------

#---------------ConfigureStorageDrsForPod_Task---------------
$pod = New-Object VMware.Vim.ManagedObjectReference
$pod.Type = 'StoragePod'
$pod.Value = 'group-p2764291'
$spec = New-Object VMware.Vim.StorageDrsConfigSpec
$spec.PodConfigSpec = New-Object VMware.Vim.StorageDrsPodConfigSpec
$spec.PodConfigSpec.DefaultVmBehavior = 'automated'
$spec.PodConfigSpec.IoLoadBalanceConfig = New-Object VMware.Vim.StorageDrsIoLoadBalanceConfig
$spec.PodConfigSpec.IoLoadBalanceConfig.IoLoadImbalanceThreshold = 5
$spec.PodConfigSpec.IoLoadBalanceConfig.IoLatencyThreshold = 15
$spec.PodConfigSpec.SpaceLoadBalanceConfig = New-Object VMware.Vim.StorageDrsSpaceLoadBalanceConfig
$spec.PodConfigSpec.SpaceLoadBalanceConfig.MinSpaceUtilizationDifference = 1
$spec.PodConfigSpec.SpaceLoadBalanceConfig.SpaceThresholdMode = 'utilization'
$spec.PodConfigSpec.SpaceLoadBalanceConfig.FreeSpaceThresholdGB = 50
$spec.PodConfigSpec.SpaceLoadBalanceConfig.SpaceUtilizationThreshold = 80
$spec.PodConfigSpec.IoLoadBalanceEnabled = $false
$spec.PodConfigSpec.DefaultIntraVmAffinity = $false
$spec.PodConfigSpec.AutomationOverrides = New-Object VMware.Vim.StorageDrsAutomationConfig
$spec.PodConfigSpec.LoadBalanceInterval = 60
$spec.PodConfigSpec.Enabled = $true
$spec.PodConfigSpec.Option = New-Object VMware.Vim.StorageDrsOptionSpec[] (0)
$modify = $true
$_this = Get-View -Id 'StorageResourceManager-StorageResourceManager'
$_this.ConfigureStorageDrsForPod_Task($pod, $spec, $modify)

#----------------- End of code capture -----------------


#----------------- Start of code capture -----------------

#---------------ConfigureStorageDrsForPod_Task---------------
$pod = New-Object VMware.Vim.ManagedObjectReference
$pod.Type = 'StoragePod'
$pod.Value = 'group-p1285430'
$spec = New-Object VMware.Vim.StorageDrsConfigSpec
$spec.PodConfigSpec = New-Object VMware.Vim.StorageDrsPodConfigSpec
$spec.PodConfigSpec.DefaultVmBehavior = 'automated'
$spec.PodConfigSpec.IoLoadBalanceConfig = New-Object VMware.Vim.StorageDrsIoLoadBalanceConfig
$spec.PodConfigSpec.IoLoadBalanceConfig.IoLoadImbalanceThreshold = 5
$spec.PodConfigSpec.IoLoadBalanceConfig.IoLatencyThreshold = 15
$spec.PodConfigSpec.SpaceLoadBalanceConfig = New-Object VMware.Vim.StorageDrsSpaceLoadBalanceConfig
$spec.PodConfigSpec.SpaceLoadBalanceConfig.MinSpaceUtilizationDifference = 1
$spec.PodConfigSpec.SpaceLoadBalanceConfig.SpaceThresholdMode = 'freeSpace'
$spec.PodConfigSpec.SpaceLoadBalanceConfig.FreeSpaceThresholdGB = 50
$spec.PodConfigSpec.SpaceLoadBalanceConfig.SpaceUtilizationThreshold = 80
$spec.PodConfigSpec.IoLoadBalanceEnabled = $false
$spec.PodConfigSpec.DefaultIntraVmAffinity = $false
$spec.PodConfigSpec.AutomationOverrides = New-Object VMware.Vim.StorageDrsAutomationConfig
$spec.PodConfigSpec.LoadBalanceInterval = 60
$spec.PodConfigSpec.Enabled = $true
$spec.PodConfigSpec.Option = New-Object VMware.Vim.StorageDrsOptionSpec[] (0)
$modify = $true
$_this = Get-View -Id 'StorageResourceManager-StorageResourceManager'
$_this.ConfigureStorageDrsForPod_Task($pod, $spec, $modify)

#----------------- End of code capture -----------------