﻿<#
*********************************************************************************
Author      - Tamilarasan G
Content     - Collect Esxi Time and NTP details
Version     - V1.0
Email       - 
CreatedDate - 11/2/2019
*********************************************************************************
#>

#Import-Module VMware.PowerCLI
$report = @()
foreach ($esx in (Get-VMHost -State Maintenance,Connected)){
$data = "" | select Name,Cluster,NTP,NTPRunningState,Timezone,Time
$data.Name = $esx.Name
$data.Cluster = $esx.Parent
$data.NTP = (Get-VMHostNtpServer -VMHost $esx) -join ','
$data.Timezone = (Get-VMHostAvailableTimeZone -VMHost $esx).Key
$data.Time = (Get-EsxCli -VMHost $esx).System.Time.get()
$data.NTPRunningState = (Get-VMHostService -VMHost $esx | where {$_.key -eq 'ntpd'}).running
$report += $data
$data | ft -AutoSize

}
$FileDate = Get-Date -Format "yyyyMMdd-HHmm"

$report | Export-Csv -Path .\"NTPDetails-$FileDate.csv" -UseCulture -NoTypeInformation
