Import-Module VMware.PowerCLI
cd D:\CloudOps\VcenterPermission

$password = Get-Content .\pass.txt | ConvertTo-SecureString -Key (Get-Content .\aes.key)
$credential = New-Object System.Management.Automation.PsCredential("Dsglobal.org\S705979",$password)

$filename = get-date -format yyyy-MM-ddTHH-mm-ss
$To = @("DL-Cloud-Ops@voya.com")
Connect-VIServer jvcewvvc9702,mvcewvvc9701,dstravce9001,astravce9001 -Credential $credential -ErrorAction SilentlyContinue
$Report = Get-VIPermission -Entity (Get-Datacenter) | Select-Object Role,Principal,Propagate,IsGroup,@{N="Vcenter";E={$_.uid.Split(�:�)[0].Split("@")[1]}}
$Info = "VMware Vcenter Permissions Details `n Regards, `n Cloud Ops Team"
$report | Export-Csv -path .\"VcPermission-$filename.csv" -UseCulture -NoTypeInformation
$file = Get-ChildItem | where {$_.Name -match "VcPermission-$filename.csv"}
Send-MailMessage -To 'Hari.subramanian@voya.com' -From "VIPermissions@voya.com" -Subject "Weekly Vcenter Permissions $filename" -Attachments $file -Body " `n`n Please find the Weekly Vcenter Permissions Report" -SmtpServer smtp1.dsglobal.org
$global:DefaultVIServers | % {Disconnect-VIServer $_ -Confirm:$false}