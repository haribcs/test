cd D:\CloudOps\HBADevicesCount
Import-Module VMware.PowerCLI,ImportExcel | Out-Null
$filename = get-date -format yyyy-MM-ddTHH-mm-ss
$SourceExcel = "D:\CloudOps\HBADevicesCount\Devcount-$filename.xlsx"
$report = @()
$Naa = @()

$password = Get-Content .\pass.txt | ConvertTo-SecureString -Key (Get-Content .\aes.key)
$credential = New-Object System.Management.Automation.PsCredential("Dsglobal.org\S705979",$password)


connect-viserver mvcewvvc9701 -credential $credential

###change pstresx148* to what host(s) you need, i.e. pshk*###
foreach($esx in ( get-cluster "SHK DATABASE CLUSTER" |Get-VMHost )){
    

    foreach($hba in (Get-VMHostHba -VMHost $esx -Type "FibreChannel" | where Status -eq "Online" )){

        $target = ((Get-View $hba.VMhost).Config.StorageDevice.ScsiTopology.Adapter | where {$_.Adapter -eq $hba.Key}).Target

        $luns = Get-ScsiLun -Hba $hba  -LunType "disk" -ErrorAction SilentlyContinue | select CanonicalName,VMHost,@{N='HBA';E={$hba}}
        $naa += $luns

        $nrPaths = ($target | %{$_.Lun.Count} | Measure-Object -Sum).Sum

 

        $props = "" | select VMhost,HBA,Devices,Paths,wwn,wwpn,cluster,Vcenter

            $props.VMhost = $esx.name
            
            $props.wwn = "{0:X}" -f $hba.NodeWorldWideName
            $props.wwpn = "{0:X}" -f $hba.PortWorldWideName
            $props.HBA = $hba.Name

            $props.cluster = $esx.parent
            
            $props.Devices = $luns.Count

            $props.Paths = $nrPaths
            $props.Vcenter = $esx.uid.split('@')[1].split(':')[0]

            
        $props | ft -AutoSize
        $report += $props

        }


    }

$report | Export-Excel -Path $SourceExcel -WorksheetName "LunCount" -AutoFilter
$Naa | Export-Excel -Path $SourceExcel -WorksheetName "LunDetails" -AutoFilter

#disconnect-viserver -confirm:$false

