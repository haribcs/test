﻿#----------------- Start of code capture -----------------

$lun = Get-Content .\RDM.txt
#---------------DetachScsiLun---------------
foreach ($lunUuid in $lun){
$_this = Get-View -Id 'HostStorageSystem-storageSystem-146797'
Write-Host "Running $lunUuid" -ForegroundColor Yellow
$_this.DetachScsiLun($lunUuid)
Write-Host "Completed $lunUuid" -ForegroundColor Green
}

#----------------- End of code capture -----------------