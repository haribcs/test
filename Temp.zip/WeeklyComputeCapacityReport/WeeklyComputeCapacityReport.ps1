﻿Import-Module VMware.PowerCLI
cd D:\CloudOps\WeeklyComputeCapacityReport

$password = Get-Content .\pass.txt | ConvertTo-SecureString -Key (Get-Content .\aes.key)
$credential = New-Object System.Management.Automation.PsCredential("Dsglobal.org\S705979",$password)

$filename = get-date -format yyyy-MM-ddTHH-mm-ss
$to = @("TRB, R. (Rangarajan) <Rangarajan.TRB@voya.com>")
$cc = @("DL-Cloud-Ops@voya.com")
$start = Get-Date

$report = @()
$vcenters = @()
#$vcenters = "Jvcewvvc9702"
$vcenters = "Mvcewvvc9701","Jvcewvvc9702"
foreach ($vcenter in $vcenters){

Connect-VIServer $vcenter -Credential $credential
Write-Host "Connected $vcenter" -ForegroundColor Yellow
$clusters = Get-View -ViewType ClusterComputeResource 
$clusters |  % {
$Allvms = Get-Cluster  $_.name | Get-VM
$vm = $Allvms | Where{$_.powerstate -eq 'Poweredon'}
$hostCount = $_.host.count
if ($hostcount -gt 0){

$data = "" | select Name,NumHost,CoresPerHost,RAMPerHost,ReservedHost,VCPUsage,VRAMUsage,AllVMs,RunningVms,Vcenter
$data.Name = $_.Name
$data.Vcenter = $vcenter
$data.AllVMs = $Allvms.count
$data.RunningVms = $vm.Count
$vmhostview = Get-View $_.host -Property Name, Hardware, Config

$HostReservation = (1 + [math]::Floor(($hostCount / 13)) )
$data.ReservedHost = $HostReservation
$data.NumHost = $hostCount
$PcpuCore = ($vmhostview | % {$_.Hardware.Cpuinfo.NumCPUcores} | measure -Average).Average
$HostMemory =  ($vmhostview | % {$_.Hardware.MemorySize /1GB} | measure -Average).Average
$data.CoresPerHost = [math]::Round($PcpuCore)
$data.RAMPerHost = [math]::Round($HostMemory)
$vmhost = ($vmhostview | select -First 1).name.substring(1,3)


#$vm = $_ | Get-VM | Where{$_.powerstate -eq 'Poweredon'}
$data.VRAMUsage = [math]::Round( ($vm | measure -Sum -Property MemoryGb).Sum)
$data.VCPUsage = [math]::Round(($vm | measure -Sum -Property NumCpu).Sum)

}
$report += $data
$data | ft -AutoSize


}
$global:DefaultVIServers | % {write-host " Disconnecting $_" ; Disconnect-VIServer $_ -Confirm:$false}

}
$end = Get-Date
$Time = New-TimeSpan -Start $start -End $end
$Info = "VMware Weekly DS Cluster Report `n Regards, `n Cloud Ops Team"
$report | Export-Csv -path .\"ComPuteClus-$filename.csv" -UseCulture -NoTypeInformation
$file = Get-ChildItem | where {$_.Name -match "ComPuteClus-$filename.csv"}
Send-MailMessage -To 'DL-cloud-ops@voya.com' -From "WeeklyComputeClusReport@voya.com" -Subject "Weekly Compute cluster $filename" -Attachments $file -Body "$time `n`n Please find the Weekly datastore Cluster Report" -SmtpServer smtp1.dsglobal.org
<#
$excel = New-Object -ComObject Excel.Application
$excel.Visible = $true
$workbook = $excel.Workbooks.Open("D:\CloudOps\WeeklyComputeCapacityReport\Index.xlsx"
#>