﻿cd D:\CloudOps\Jbossesxinfo
$report = @()
$filename = get-date -format yyyy-MM-ddTHH-mm-ss
$to = @("Kanagarajan, S. (Selvakumar) <Selvakumar.Kanagarajan@voya.com>")
$cc = @("DL-Cloud-Ops@voya.com")
Import-Module VMware.PowerCLI

$password = Get-Content .\pass.txt | ConvertTo-SecureString -Key (Get-Content .\aes.key)
$credential = New-Object System.Management.Automation.PsCredential("Dsglobal.org\S705979",$password)
Connect-VIServer mvcewvvc9701,jvcewvvc9702 -Credential $credential
$cluster = Get-Cluster "SHK JBOSS CLUSTER","SHK PLATINUM LINUX PROD1","STR JBOSS CLUSTER1","STR JBOSS CLUSTER2","STR PLATINUM LINUX PROD1"
foreach ($esx in ($cluster | Get-VMHost)){
$data = "" | select Host,IP,Datacenter,Cluster,ConfigStatus,CPUModel,CPUSpeed,HTAvailabe,HTActive,NumberCPU,CoresPerCPU,NumCore,CPUUsage,MemoryGB,MemoryUsage
$data.Host = $esx.Name
$data.IP = $esx.ExtensionData.Summary.ManagementServerIp
$data.Cluster = $esx.Parent
$data.Datacenter=  ($esx | Get-Datacenter).Name
$data.ConfigStatus = $esx.ExtensionData.Summary.OverallStatus
$data.CPUModel = $esx.ExtensionData.Summary.Hardware.CpuModel.Split('@')[0]
$data.CPUSpeed = $esx.ExtensionData.Summary.Hardware.CpuModel.Split('@')[1]
$data.HTAvailabe = "True"
$data.HTActive = $esx.HyperthreadingActive
$data.NumberCPU = $esx.ExtensionData.Hardware.CpuInfo.NumCpuPackages
$data.CoresPerCPU = $esx.ExtensionData.Hardware.CpuInfo.NumCpuCores/$esx.ExtensionData.Hardware.CpuInfo.NumCpuPackages
$data.NumCore = $esx.ExtensionData.Hardware.CpuInfo.NumCpuCores
$data.CPUUsage = [math]::Round($esx.CpuUsageMhz *100 /$esx.CpuTotalMhz)
$data.MemoryGB = [math]::Round($esx.MemoryTotalGB)
$data.MemoryUsage = [math]::Round($esx.MemoryUsageGB *100 / $esx.MemoryTotalGB)
$report += $data
$data | fl
}
#$report | Export-Csv .\
$report | Export-Csv -Path .\"JbossEsxReport-$filename.csv" -UseCulture -NoTypeInformation
$file = Get-ChildItem | where {$_.Name -match "$filename.csv"}
Send-MailMessage -To 'Hari.subramanian@voya.com' -From "JbossMonthlyReport@voya.com" -Cc $cc -Subject "Jboss Monthly Report $filename" -Attachments $file -Body "$info `n $time"-SmtpServer smtp1.dsglobal.org


