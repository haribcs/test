﻿Import-Module VMware.PowerCLI,ImportExcel
$vms = @()

$date = Get-Date -UFormat "%B-%Y"
cd D:\CloudOps\VirtualizationReport

$to = @("Hussain N, S. (Syed Naazim) <SyedNaazim.HussainN@voya.com>"," Vishweshwara, A. (Adarsha) <Adarsha.Vishweshwara@voya.com>","Aslam, A. (AJ) <AJ.Aslam@voya.com>", "N R, G. (Gopinath) <Gopinath.NR@voya.com>", "Kumar, S. (Santhosh) <Santhosh.Kumar@voya.com>")
$cc = @("DL-Cloud-Ops <DL-Cloud-Ops@voya.com>"," UNIX-ID_TBO <UNIX-ID/TBO@voya.com>","DL-US-Distributed-Systems-Intel <DL-US-Distributed-Systems-Intel@dsglobal.org>")

$password = Get-Content .\pass.txt | ConvertTo-SecureString -Key (Get-Content .\aes.key)
$credential = New-Object System.Management.Automation.PsCredential("Dsglobal.org\S705979",$password)


$excel = "D:\CloudOps\VirtualizationReport\VirtualizationReport-$date.xlsx"
Connect-VIServer mvcewvvc9701,jvcewvvc9702,astravce9001,dstravce9001,pmplavvc9100 -Credential $credential
$esxi = Get-VMHost | select Name,@{N='Cluster';E={$_.parent}},@{N='Vcenter';E={$_.Uid.Split('@')[1].split(':')[0]}},@{N='Version';E={$_.version+"-"+$_.Build}}
foreach ($vm in (get-vm)){
$data = "" | select ServerName,VirtualServer,Powerstate,VMhost,Cluster,Vcenter
$data.ServerName = $vm.Name
$data.Powerstate = $vm.PowerState
$data.VMhost = $vm.VMHost
$data.Cluster = $data.VMhost.parent
$data.Vcenter = $vm.Uid.Split('@')[1].split(':')[0]
if ($vm.Guest.OSFullName -ne $null){$data.VirtualServer = $vm.Guest.OSFullName}else{
$data.VirtualServer = $vm.ExtensionData.Config.GuestFullName
}

$data | ft -AutoSize
$vms += $data

}


$global:DefaultVIServers | % {Disconnect-VIServer $_ -Confirm:$false}

$vms | Export-Excel -Path $excel -WorksheetName "Virtualization Report" -AutoSize -AutoFilter
$esxi | Export-Excel -Path $excel -WorksheetName "Host Version" -AutoSize -AutoFilter
$file = Get-ChildItem -Name $excel
Send-MailMessage -To Hari.subramanian@voya.com -From Virtualizationreport@voya.com -Subject "Virtaulization Report $date" -Body "Hi All `n`n Please find the Virtialization Report for $date `n`n Regards `n Cloud Ops" -SmtpServer smtp1.dsglobal.org -Attachments $file