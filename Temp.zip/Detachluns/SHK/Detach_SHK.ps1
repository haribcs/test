#############################################################################################################
##script:           Unmount_Detach-Datastore.ps1
##############################################################################################################
function Connect-Vcenter {
    
    ##Function:         Connect-Vcenter
    
    param(
        $vcenter
    )
    #Load snap-in
    if (-not (Get-PSSnapin -Name VMware.VimAutomation.Core -erroraction "silentlycontinue" )) {
        Write-Host "Importing VMWare Snap-in VMware.VimAutomation.Core..."   
        Add-PSSnapin VMware.VimAutomation.Core
    }
    Set-PowerCLIConfiguration -DefaultVIServerMode Single -invalidCertificateAction "ignore" -confirm:$false | out-null
    #Connect to vCenter
    if ($global:DefaultVIServers.Count -lt 1) {
        Write-Host "Connecting to vcenter server $vcenter..."      
        Connect-VIServer $vCenter
    }
}
Function Get-DatastoreMountInfo {
    
    [CmdletBinding()]
    Param (
        [Parameter(ValueFromPipeline=$true)]
        $Datastore
    )
    Process {
        $AllInfo = @()
	    if (-not $Datastore) {
            $Datastore = Get-Datastore
        }
        Foreach ($ds in $Datastore) {  
            if ($ds.ExtensionData.info.Vmfs) {
                $hostviewDSDiskName = $ds.ExtensionData.Info.vmfs.extent[0].diskname
                if ($ds.ExtensionData.Host) {
                    $attachedHosts = $ds.ExtensionData.Host
                    Foreach ($VMHost in $attachedHosts) {
                        $hostview = Get-View $VMHost.Key
                        $hostviewDSState = $VMHost.MountInfo.Mounted
                        $StorageSys = Get-View $HostView.ConfigManager.StorageSystem
                        $devices = $StorageSys.StorageDeviceInfo.ScsiLun
                        Foreach ($device in $devices) {
                            $Info = '' | Select Datastore, VMHost, Lun, Mounted, State
                            if ($device.canonicalName -eq $hostviewDSDiskName) {
                                $hostviewDSAttachState = ''
                                if ($device.operationalState[0] -eq "ok") {
                                    $hostviewDSAttachState = "Attached"                        
                                } elseif ($device.operationalState[0] -eq "off") {
                                    $hostviewDSAttachState = "Detached"                        
                                } else {
                                    $hostviewDSAttachState = $device.operationalstate[0]
                                }
                                $Info.Datastore = $ds.Name
                                $Info.Lun = $hostviewDSDiskName
                                $Info.VMHost = $hostview.Name
                                $Info.Mounted = $HostViewDSState
                                $Info.State = $hostviewDSAttachState
                                $AllInfo += $Info
                            }
                        }
                         
                    }
                }
            }
        }
        $AllInfo
    }
}

Function Detach-Datastore {
    
    [CmdletBinding()]
    Param (
        [Parameter(ValueFromPipeline=$true)]
        $Datastore
    )
    Process {
        if (-not $Datastore) {
            Write-Host "No Datastore defined as input"
            Exit
        }
        Foreach ($ds in $Datastore) {
            $hostviewDSDiskName = $ds.ExtensionData.Info.vmfs.extent[0].Diskname
            if ($ds.ExtensionData.Host) {
                $attachedHosts = $ds.ExtensionData.Host
                Foreach ($VMHost in $attachedHosts) {
                    $hostview = Get-View $VMHost.Key
                    $StorageSys = Get-View $HostView.ConfigManager.StorageSystem
                    $devices = $StorageSys.StorageDeviceInfo.ScsiLun
                    Foreach ($device in $devices) {
                        if ($device.canonicalName -eq $hostviewDSDiskName) {
                            #If the device is attached then detach it 
                            if ($device.operationalState[0] -eq "ok") { 
                                $LunUUID = $Device.Uuid
                                Write-Host "Detaching LUN $($Device.CanonicalName) from host $($hostview.Name)..."
                                $StorageSys.DetachScsiLun($LunUUID);

				
                            }
                            #If the device isn't attached then skip it 
                            else {
                                Write-Host "LUN $($Device.CanonicalName) is not attached on host $($hostview.Name)..."
                            }
                        }
                    }
                }
            }
        }
    }
}
Function Unmount-Datastore {
    
    [CmdletBinding()]
    Param (
        [Parameter(ValueFromPipeline=$true)]
        $Datastore
    )
    Process {
        if (-not $Datastore) {
            Write-Host "No Datastore defined as input"
            Exit
        }
        Foreach ($ds in $Datastore) {
            $hostviewDSDiskName = $ds.ExtensionData.Info.vmfs.extent[0].Diskname
            if ($ds.ExtensionData.Host) {
                $attachedHosts = $ds.ExtensionData.Host
                Foreach ($VMHost in $attachedHosts) {
                    $hostview = Get-View $VMHost.Key
                    $mounted = $VMHost.MountInfo.Mounted
                    #If the device is mounted then unmount it (I added this to the function to prevent error messages in vcenter when running the script)
                    if ($mounted -eq $true) {
                        $StorageSys = Get-View $HostView.ConfigManager.StorageSystem
                        Write-Host "Unmounting VMFS Datastore $($DS.Name) from host $($hostview.Name)..."
                        $StorageSys.UnmountVmfsVolume($DS.ExtensionData.Info.vmfs.uuid);
                    }
                    #If the device isn't mounted then skip it (I added this to the function to prevent error messages in vcenter when running the script)
                    else {
                        Write-Host "VMFS Datastore $($DS.Name) is already unmounted on host $($hostview.Name)..."
                    }
                }
            }
        }
    }
}
#VARIABLES
#Parameters 
$vcenter = "mvcewvvc9701"
$DSName = Read-Host "Provide the datastore name: "
$user = "administrator.vsphere.local"
$password = "VMwar3!!VMwar3!!"
#SCRIPT MAIN
clear
Connect-Vcenter $vcenter -user $user -password $password
$datastore = Get-Datastore -Name $DSName
$CanonicalName = $datastore.ExtensionData.Info.Vmfs.Extent[0].DiskName
$GoAhead = Read-Host "Are you sure that you want to unmount and detach: `n$DSName `n$CanonicalName`nfrom all its connected hosts?"
if ($GoAhead -eq "yes" -or $GoAhead -eq "y" -or $GoAhead -eq "Y") {
    Write-Host "Unmounting datastore $DSName..."   
    $datastore | Unmount-Datastore
    Write-Host "Detaching datastore $DSName from hosts..."
    $datastore | Detach-Datastore
  }
$RescanVMFS = Get-datastore -Name $datastore | Get-vmHost | Get-VMHostStorage -RescanVmfs
$DSName
$CanonicalName