﻿$ErrorActionPreference = "SilentlyContinue"
param (
$ReportOutputPath
)
Import-Module H:\Scripts\Enhancement\ReportHTML-master\ReportHTML\ReportHTML.psd1
Get-Command -Module ReportHtml

if (!$ReportOutputPath) 
{
	$ReportOutputPath = Split-Path -Path H:\Scripts\Enhancement\Enhanced\Htmlreport\report -Parent
}
Get-Module -ListAvailable | where{$_.Name -match "vmware*"} | Import-Module
cd H:\Scripts\powernsx-Add-Get-NsxIPsecStats\powernsx-Add-Get-NsxIPsecStats\module
Import-Module .\PowerNSX.psm1
cd\
Function Test-Report 
{
	param (
		$TestName
	)
	$rptFile = join-path $ReportOutputPath ($ReportName.replace(" ","") + "-$TestName" + "_$(get-date -f yyyy-MM-dd-HH-mm-ss).htm")
	$rpt | Set-Content -Path $rptFile -Force
	Invoke-Item $rptFile
	sleep 1
}

$Username = "admin"
$Password = Get-Content H:\Scripts\Enhancement\Enhanced\Credentials.txt | ConvertTo-SecureString
$Cred = New-Object -Typename System.Management.Automation.PSCredential -ArgumentList $Username, $Password
$Pzssword = Get-Content H:\Scripts\Enhancement\Enhanced\zCredentials.txt | ConvertTo-SecureString
$Credz = New-Object -Typename System.Management.Automation.PSCredential -ArgumentList $Username, $Pzssword
#nsx controller#
Connect-VIServer -Server 10.174.14.9 -User "vcsadmin@wpp.net" -Password pM0dularc
Connect-NsxServer -NsxServer 10.113.48.204 -Credential $Cred 
$ReportName = "NSX Health Check Report"
$nsxctrl = Get-NsxController
#$ctrl = ($nsxctrl |  Where-Object {$_.status} | select ID,STATUS,IPADDRESS) 
#$Red = '$this.status -ge 2'
#$Yellow = '$this.status -eq running'
#$Green = '$this.status -ge 3'

#$Coloured =  Set-TableRowColor $ctrl -Red $Red -Yellow $Yellow -Green $Green 

$rpt = @()
$rpt += Get-HTMLOpenPage -TitleText $ReportName
$rpt += Get-htmlcontentopen -HeaderText "Nsx Controller" -IsHidden
$rpt += Get-HTMLContentOpen -HeaderText "Piller 2 Controller" -IsHidden
$rpt += Get-HTMLContentOpen -HeaderText "London (LN2) Controller" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Controller" -Detail ("Running " + ($nsxctrl | ? {$_.status -eq 'Running'} | measure ).count + " / Stopped " + ($nsxctrl | ? {$_.status -eq 'Stopped'} | measure ).count)
$rpt += Get-HtmlContentTable ($nsxctrl |  Where-Object {$_.status} | select ID,STATUS,IPADDRESS)
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
Disconnect-NsxServer
Connect-VIServer -Server 10.150.33.6 -User "vcsadmin@wpp.net" -Password pM0dularc
Connect-NsxServer -NsxServer 10.150.33.9 -Credential $Cred
$nsxctrl1 = Get-NsxController
$rpt += Get-HTMLContentOpen -HeaderText "Brazil (BR1) Controller" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Controller" -Detail ("Running " + ($nsxctrl1 | ? {$_.status -eq 'Running'} | measure ).count + " / Stopped " + ($nsxctrl1 | ? {$_.status -eq 'Stopped'} | measure ).count)
$rpt += Get-HtmlContentTable ($nsxctrl1 |  Where-Object {$_.status} | select ID,STATUS,IPADDRESS) 
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
Disconnect-NsxServer
Connect-VIServer -Server 10.117.167.136 -User "vcsadmin@wpp.net" -Password pM0dularc
Connect-NsxServer -NsxServer axsg1pnsx0001.wpp.net -Credential $Credz
$nsxctrl1 = Get-NsxController
$rpt += Get-HTMLContentOpen -HeaderText "Singapore (SG1) Controller" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Controller" -Detail ("Running " + ($nsxctrl1 | ? {$_.status -eq 'Running'} | measure ).count + " / Stopped " + ($nsxctrl1 | ? {$_.status -eq 'Stopped'} | measure ).count)
$rpt += Get-HtmlContentTable ($nsxctrl1 |  Where-Object {$_.status} | select ID,STATUS,IPADDRESS) 
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
Disconnect-NsxServer
Connect-VIServer -Server 10.125.127.72 -User "vcsadmin@wpp.net" -Password pM0dularc
Connect-NsxServer -NsxServer 10.125.127.76 -Credential $Credz
$nsxctrl1 = Get-NsxController
$rpt += Get-HTMLContentOpen -HeaderText "Wahsington (WD1) Controller" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Controller" -Detail ("Running " + ($nsxctrl1 | ? {$_.status -eq 'Running'} | measure ).count + " / Stopped " + ($nsxctrl1 | ? {$_.status -eq 'Stopped'} | measure ).count)
$rpt += Get-HtmlContentTable ($nsxctrl1 |  Where-Object {$_.status} | select ID,STATUS,IPADDRESS) 
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
Disconnect-NsxServer
Connect-VIServer -Server 10.172.20.160 -User "vcsadmin@wpp.net" -Password pM0dularc
Connect-NsxServer -NsxServer 10.172.20.180 -Credential $Cred
$nsxctrl1 = Get-NsxController
$rpt += Get-HTMLContentOpen -HeaderText "Piller 3 Controller" -IsHidden
$rpt += Get-HTMLContentOpen -HeaderText "London (EDO) Controller" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Controller" -Detail ("Running " + ($nsxctrl1 | ? {$_.status -eq 'Running'} | measure ).count + " / Stopped " + ($nsxctrl1 | ? {$_.status -eq 'Stopped'} | measure ).count)
$rpt += Get-HtmlContentTable ($nsxctrl1 |  Where-Object {$_.status} | select ID,STATUS,IPADDRESS) 
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
Disconnect-NsxServer
Connect-VIServer -Server 10.186.20.160 -User "vcsadmin@wpp.net" -Password pM0dularc
Connect-NsxServer -NsxServer 10.186.20.180 -Credential $Cred
$nsxctrl1 = Get-NsxController
$rpt += Get-HTMLContentOpen -HeaderText "Singapore (ADO) Controller" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Controller" -Detail ("Running " + ($nsxctrl1 | ? {$_.status -eq 'Running'} | measure ).count + " / Stopped " + ($nsxctrl1 | ? {$_.status -eq 'Stopped'} | measure ).count)
$rpt += Get-HtmlContentTable ($nsxctrl1 |  Where-Object {$_.status} | select ID,STATUS,IPADDRESS) 
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
Disconnect-NsxServer
Connect-VIServer -Server 10.176.20.160 -User "vcsadmin@wpp.net" -Password pM0dularc
Connect-NsxServer -NsxServer 10.176.20.180 -Credential $Cred
$nsxctrl1 = Get-NsxController
$rpt += Get-HTMLContentOpen -HeaderText "US Raleigh (UDO) Controller" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Controller" -Detail ("Running " + ($nsxctrl1 | ? {$_.status -eq 'Running'} | measure ).count + " / Stopped " + ($nsxctrl1 | ? {$_.status -eq 'Stopped'} | measure ).count)
$rpt += Get-HtmlContentTable ($nsxctrl1 |  Where-Object {$_.status} | select ID,STATUS,IPADDRESS) 
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
Disconnect-NsxServer
Connect-VIServer -Server 10.182.20.160 -User "vcsadmin@wpp.net" -Password pM0dularc
Connect-NsxServer -NsxServer 10.182.20.180 -Credential $Cred
$nsxctrl1 = Get-NsxController
$rpt += Get-HTMLContentOpen -HeaderText "Brazil (LDO) Controller" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Controller" -Detail ("Running " + ($nsxctrl1 | ? {$_.status -eq 'Running'} | measure ).count + " / Stopped " + ($nsxctrl1 | ? {$_.status -eq 'Stopped'} | measure ).count)
$rpt += Get-HtmlContentTable ($nsxctrl1 |  Where-Object {$_.status} | select ID,STATUS,IPADDRESS) 
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
Disconnect-NsxServer

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

#nsx manager summary#
Connect-VIServer -Server 10.174.14.9 -User "vcsadmin@wpp.net" -Password pM0dularc
Connect-NsxServer -NsxServer 10.113.48.204 -Credential $Cred
$nsxmgrsys = Get-NsxManagerSystemSummary
$nsxmgrcom = Get-NsxManagerComponentSummary
$nsxmgrsso = Get-NsxManagerSsoConfig
$nsxmgrvCenter = Get-NsxManagerVcenterConfig
$nsxmgrsyslog = Get-NsxManagerSyslogServer
$nsxmgrtime = Get-NsxManagerTimeSettings
$rpt += Get-htmlcontentopen -HeaderText "NSX Manager Summary" -IsHidden
$rpt += Get-htmlcontentopen -HeaderText "Piller 2 NSX Manager Summary" -IsHidden
$rpt += Get-HTMLContentOpen -HeaderText "London (LN2) NSX Manager Summary" -IsHidden
$rpt += Get-HtmlContenttext -Heading "System Summary"
$rpt += Get-HtmlContentTable ($nsxmgrsys | select applianceName,currentSystemDate,domainName,hostName,ipv4Address,uptime) 
$rpt += Get-HtmlContentTable ($nsxmgrsys.cpuInfoDto | select capacity,freeCapacity,totalNoOfCPUs,usedCapacity,usedPercentage) 
$rpt += Get-HtmlContentTable ($nsxmgrsys.memInfoDto | select freeMemory,totalMemory,usedMemory,usedPercentage) 
$rpt += Get-HtmlContentTable ($nsxmgrsys.storageInfoDto | select freeStorage,totalStorage,usedPercentage,usedStorage)
$rpt += Get-HtmlContentTable ($nsxmgrsys.versionInfo | select buildNumber,majorVersion,MinorVersion,patchVersion)
$rpt += Get-HtmlContenttext -Heading "System Component"
$rpt += Get-HtmlContentTable ($nsxmgrcom.componentsByGroup.entry.GetEnumerator().components.component | select componentGroup,componentId,description,enabled,name,status)
$rpt += Get-HtmlContenttext -Heading "Sso Config"
$rpt += Get-HtmlContentTable ($nsxmgrsso | select vsmSolutionName,ssoLookupServiceUrl,ssoAdminUsername,Connected)
$rpt += Get-HtmlContenttext -Heading "vCenter Config"
$rpt += Get-HtmlContentTable ($nsxmgrvCenter | select ipAddress,userName,CertificateThumbprint,assignRoleToUser,vcInventoryLastUpdateTime,Connected)
$rpt += Get-HtmlContenttext -Heading "Syslog Server"
$rpt += Get-HtmlContentTable ($nsxmgrsyslog | select syslogServer,port,protocol)
$rpt += Get-HtmlContenttext -Heading "Time Settings Ntp Server" -Detail ($nsxmgrtime.ntpServer.string)
$rpt += Get-HtmlContentTable ($nsxmgrtime | select datetime,timezone)
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
Disconnect-NsxServer

Connect-VIServer -Server 10.150.33.6 -User "vcsadmin@wpp.net" -Password pM0dularc
Connect-NsxServer -NsxServer 10.150.33.9 -Credential $Cred
$nsxmgrsys = Get-NsxManagerSystemSummary
$nsxmgrcom = Get-NsxManagerComponentSummary
$nsxmgrsso = Get-NsxManagerSsoConfig
$nsxmgrvCenter = Get-NsxManagerVcenterConfig
$nsxmgrsyslog = Get-NsxManagerSyslogServer
$nsxmgrtime = Get-NsxManagerTimeSettings
$rpt += Get-HTMLContentOpen -HeaderText "Brazil (BR1) NSX Manager Summary" -IsHidden
$rpt += Get-HtmlContenttext -Heading "System Summary"
$rpt += Get-HtmlContentTable ($nsxmgrsys | select applianceName,currentSystemDate,domainName,hostName,ipv4Address,uptime) 
$rpt += Get-HtmlContentTable ($nsxmgrsys.cpuInfoDto | select capacity,freeCapacity,totalNoOfCPUs,usedCapacity,usedPercentage) 
$rpt += Get-HtmlContentTable ($nsxmgrsys.memInfoDto | select freeMemory,totalMemory,usedMemory,usedPercentage) 
$rpt += Get-HtmlContentTable ($nsxmgrsys.storageInfoDto | select freeStorage,totalStorage,usedPercentage,usedStorage)
$rpt += Get-HtmlContentTable ($nsxmgrsys.versionInfo | select buildNumber,majorVersion,MinorVersion,patchVersion)
$rpt += Get-HtmlContenttext -Heading "System Component"
$rpt += Get-HtmlContentTable ($nsxmgrcom.componentsByGroup.entry.GetEnumerator().components.component | select componentGroup,componentId,description,enabled,name,status)
$rpt += Get-HtmlContenttext -Heading "Sso Config"
$rpt += Get-HtmlContentTable ($nsxmgrsso | select vsmSolutionName,ssoLookupServiceUrl,ssoAdminUsername,Connected)
$rpt += Get-HtmlContenttext -Heading "vCenter Config"
$rpt += Get-HtmlContentTable ($nsxmgrvCenter | select ipAddress,userName,CertificateThumbprint,assignRoleToUser,vcInventoryLastUpdateTime,Connected)
$rpt += Get-HtmlContenttext -Heading "Syslog Server"
$rpt += Get-HtmlContentTable ($nsxmgrsyslog | select syslogServer,port,protocol)
$rpt += Get-HtmlContenttext -Heading "Time Settings Ntp Server" -Detail ($nsxmgrtime.ntpServer.string)
$rpt += Get-HtmlContentTable ($nsxmgrtime | select datetime,timezone)
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
Disconnect-NsxServer

Connect-VIServer -Server 10.117.167.136 -User "vcsadmin@wpp.net" -Password pM0dularc
Connect-NsxServer -NsxServer axsg1pnsx0001.wpp.net -Credential $Credz
$nsxmgrsys = Get-NsxManagerSystemSummary
$nsxmgrcom = Get-NsxManagerComponentSummary
$nsxmgrsso = Get-NsxManagerSsoConfig
$nsxmgrvCenter = Get-NsxManagerVcenterConfig
$nsxmgrsyslog = Get-NsxManagerSyslogServer
$nsxmgrtime = Get-NsxManagerTimeSettings
$rpt += Get-HTMLContentOpen -HeaderText "Singapore (SG1) NSX Manager Summary" -IsHidden
$rpt += Get-HtmlContenttext -Heading "System Summary"
$rpt += Get-HtmlContentTable ($nsxmgrsys | select applianceName,currentSystemDate,domainName,hostName,ipv4Address,uptime) 
$rpt += Get-HtmlContentTable ($nsxmgrsys.cpuInfoDto | select capacity,freeCapacity,totalNoOfCPUs,usedCapacity,usedPercentage) 
$rpt += Get-HtmlContentTable ($nsxmgrsys.memInfoDto | select freeMemory,totalMemory,usedMemory,usedPercentage) 
$rpt += Get-HtmlContentTable ($nsxmgrsys.storageInfoDto | select freeStorage,totalStorage,usedPercentage,usedStorage)
$rpt += Get-HtmlContentTable ($nsxmgrsys.versionInfo | select buildNumber,majorVersion,MinorVersion,patchVersion)
$rpt += Get-HtmlContenttext -Heading "System Component"
$rpt += Get-HtmlContentTable ($nsxmgrcom.componentsByGroup.entry.GetEnumerator().components.component | select componentGroup,componentId,description,enabled,name,status)
$rpt += Get-HtmlContenttext -Heading "Sso Config"
$rpt += Get-HtmlContentTable ($nsxmgrsso | select vsmSolutionName,ssoLookupServiceUrl,ssoAdminUsername,Connected)
$rpt += Get-HtmlContenttext -Heading "vCenter Config"
$rpt += Get-HtmlContentTable ($nsxmgrvCenter | select ipAddress,userName,CertificateThumbprint,assignRoleToUser,vcInventoryLastUpdateTime,Connected)
$rpt += Get-HtmlContenttext -Heading "Syslog Server"
$rpt += Get-HtmlContentTable ($nsxmgrsyslog | select syslogServer,port,protocol)
$rpt += Get-HtmlContenttext -Heading "Time Settings Ntp Server" -Detail ($nsxmgrtime.ntpServer.string)
$rpt += Get-HtmlContentTable ($nsxmgrtime | select datetime,timezone)
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
Disconnect-NsxServer

Connect-VIServer -Server 10.125.127.72 -User "vcsadmin@wpp.net" -Password pM0dularc
Connect-NsxServer -NsxServer 10.125.127.76 -Credential $Credz
$nsxmgrsys = Get-NsxManagerSystemSummary
$nsxmgrcom = Get-NsxManagerComponentSummary
$nsxmgrsso = Get-NsxManagerSsoConfig
$nsxmgrvCenter = Get-NsxManagerVcenterConfig
$nsxmgrsyslog = Get-NsxManagerSyslogServer
$nsxmgrtime = Get-NsxManagerTimeSettings
$rpt += Get-HTMLContentOpen -HeaderText "Washington  (WD1) NSX Manager Summary" -IsHidden
$rpt += Get-HtmlContenttext -Heading "System Summary"
$rpt += Get-HtmlContentTable ($nsxmgrsys | select applianceName,currentSystemDate,domainName,hostName,ipv4Address,uptime) 
$rpt += Get-HtmlContentTable ($nsxmgrsys.cpuInfoDto | select capacity,freeCapacity,totalNoOfCPUs,usedCapacity,usedPercentage) 
$rpt += Get-HtmlContentTable ($nsxmgrsys.memInfoDto | select freeMemory,totalMemory,usedMemory,usedPercentage) 
$rpt += Get-HtmlContentTable ($nsxmgrsys.storageInfoDto | select freeStorage,totalStorage,usedPercentage,usedStorage)
$rpt += Get-HtmlContentTable ($nsxmgrsys.versionInfo | select buildNumber,majorVersion,MinorVersion,patchVersion)
$rpt += Get-HtmlContenttext -Heading "System Component"
$rpt += Get-HtmlContentTable ($nsxmgrcom.componentsByGroup.entry.GetEnumerator().components.component | select componentGroup,componentId,description,enabled,name,status)
$rpt += Get-HtmlContenttext -Heading "Sso Config"
$rpt += Get-HtmlContentTable ($nsxmgrsso | select vsmSolutionName,ssoLookupServiceUrl,ssoAdminUsername,Connected)
$rpt += Get-HtmlContenttext -Heading "vCenter Config"
$rpt += Get-HtmlContentTable ($nsxmgrvCenter | select ipAddress,userName,CertificateThumbprint,assignRoleToUser,vcInventoryLastUpdateTime,Connected)
$rpt += Get-HtmlContenttext -Heading "Syslog Server"
$rpt += Get-HtmlContentTable ($nsxmgrsyslog | select syslogServer,port,protocol)
$rpt += Get-HtmlContenttext -Heading "Time Settings Ntp Server" -Detail ($nsxmgrtime.ntpServer.string)
$rpt += Get-HtmlContentTable ($nsxmgrtime | select datetime,timezone)
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
Disconnect-NsxServer

Connect-VIServer -Server 10.172.20.160 -User "vcsadmin@wpp.net" -Password pM0dularc
Connect-NsxServer -NsxServer 10.172.20.180 -Credential $Cred
$nsxmgrsys = Get-NsxManagerSystemSummary
$nsxmgrcom = Get-NsxManagerComponentSummary
$nsxmgrsso = Get-NsxManagerSsoConfig
$nsxmgrvCenter = Get-NsxManagerVcenterConfig
$nsxmgrsyslog = Get-NsxManagerSyslogServer
$nsxmgrtime = Get-NsxManagerTimeSettings
$rpt += Get-htmlcontentopen -HeaderText "Piller 3 NSX Manager Summary" -IsHidden
$rpt += Get-HTMLContentOpen -HeaderText "London (EDO) NSX Manager Summary" -IsHidden
$rpt += Get-HtmlContenttext -Heading "System Summary"
$rpt += Get-HtmlContentTable ($nsxmgrsys | select applianceName,currentSystemDate,domainName,hostName,ipv4Address,uptime) 
$rpt += Get-HtmlContentTable ($nsxmgrsys.cpuInfoDto | select capacity,freeCapacity,totalNoOfCPUs,usedCapacity,usedPercentage) 
$rpt += Get-HtmlContentTable ($nsxmgrsys.memInfoDto | select freeMemory,totalMemory,usedMemory,usedPercentage) 
$rpt += Get-HtmlContentTable ($nsxmgrsys.storageInfoDto | select freeStorage,totalStorage,usedPercentage,usedStorage)
$rpt += Get-HtmlContentTable ($nsxmgrsys.versionInfo | select buildNumber,majorVersion,MinorVersion,patchVersion)
$rpt += Get-HtmlContenttext -Heading "System Component"
$rpt += Get-HtmlContentTable ($nsxmgrcom.componentsByGroup.entry.GetEnumerator().components.component | select componentGroup,componentId,description,enabled,name,status)
$rpt += Get-HtmlContenttext -Heading "Sso Config"
$rpt += Get-HtmlContentTable ($nsxmgrsso | select vsmSolutionName,ssoLookupServiceUrl,ssoAdminUsername,Connected)
$rpt += Get-HtmlContenttext -Heading "vCenter Config"
$rpt += Get-HtmlContentTable ($nsxmgrvCenter | select ipAddress,userName,CertificateThumbprint,assignRoleToUser,vcInventoryLastUpdateTime,Connected)
$rpt += Get-HtmlContenttext -Heading "Syslog Server"
$rpt += Get-HtmlContentTable ($nsxmgrsyslog | select syslogServer,port,protocol)
$rpt += Get-HtmlContenttext -Heading "Time Settings Ntp Server" -Detail ($nsxmgrtime.ntpServer.string)
$rpt += Get-HtmlContentTable ($nsxmgrtime | select datetime,timezone)
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
Disconnect-NsxServer

Connect-VIServer -Server 10.186.20.160 -User "vcsadmin@wpp.net" -Password pM0dularc
Connect-NsxServer -NsxServer 10.186.20.180 -Credential $Cred
$nsxmgrsys = Get-NsxManagerSystemSummary
$nsxmgrcom = Get-NsxManagerComponentSummary
$nsxmgrsso = Get-NsxManagerSsoConfig
$nsxmgrvCenter = Get-NsxManagerVcenterConfig
$nsxmgrsyslog = Get-NsxManagerSyslogServer
$nsxmgrtime = Get-NsxManagerTimeSettings
$rpt += Get-HTMLContentOpen -HeaderText "Singapore (ADO) NSX Manager Summary" -IsHidden
$rpt += Get-HtmlContenttext -Heading "System Summary"
$rpt += Get-HtmlContentTable ($nsxmgrsys | select applianceName,currentSystemDate,domainName,hostName,ipv4Address,uptime) 
$rpt += Get-HtmlContentTable ($nsxmgrsys.cpuInfoDto | select capacity,freeCapacity,totalNoOfCPUs,usedCapacity,usedPercentage) 
$rpt += Get-HtmlContentTable ($nsxmgrsys.memInfoDto | select freeMemory,totalMemory,usedMemory,usedPercentage) 
$rpt += Get-HtmlContentTable ($nsxmgrsys.storageInfoDto | select freeStorage,totalStorage,usedPercentage,usedStorage)
$rpt += Get-HtmlContentTable ($nsxmgrsys.versionInfo | select buildNumber,majorVersion,MinorVersion,patchVersion)
$rpt += Get-HtmlContenttext -Heading "System Component"
$rpt += Get-HtmlContentTable ($nsxmgrcom.componentsByGroup.entry.GetEnumerator().components.component | select componentGroup,componentId,description,enabled,name,status)
$rpt += Get-HtmlContenttext -Heading "Sso Config"
$rpt += Get-HtmlContentTable ($nsxmgrsso | select vsmSolutionName,ssoLookupServiceUrl,ssoAdminUsername,Connected)
$rpt += Get-HtmlContenttext -Heading "vCenter Config"
$rpt += Get-HtmlContentTable ($nsxmgrvCenter | select ipAddress,userName,CertificateThumbprint,assignRoleToUser,vcInventoryLastUpdateTime,Connected)
$rpt += Get-HtmlContenttext -Heading "Syslog Server"
$rpt += Get-HtmlContentTable ($nsxmgrsyslog | select syslogServer,port,protocol)
$rpt += Get-HtmlContenttext -Heading "Time Settings Ntp Server" -Detail ($nsxmgrtime.ntpServer.string)
$rpt += Get-HtmlContentTable ($nsxmgrtime | select datetime,timezone)
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
Disconnect-NsxServer

Connect-VIServer -Server 10.176.20.160 -User "vcsadmin@wpp.net" -Password pM0dularc
Connect-NsxServer -NsxServer 10.176.20.180 -Credential $Cred
$nsxmgrsys = Get-NsxManagerSystemSummary
$nsxmgrcom = Get-NsxManagerComponentSummary
$nsxmgrsso = Get-NsxManagerSsoConfig
$nsxmgrvCenter = Get-NsxManagerVcenterConfig
$nsxmgrsyslog = Get-NsxManagerSyslogServer
$nsxmgrtime = Get-NsxManagerTimeSettings
$rpt += Get-HTMLContentOpen -HeaderText "US Raleigh  (UDO) NSX Manager Summary" -IsHidden
$rpt += Get-HtmlContenttext -Heading "System Summary"
$rpt += Get-HtmlContentTable ($nsxmgrsys | select applianceName,currentSystemDate,domainName,hostName,ipv4Address,uptime) 
$rpt += Get-HtmlContentTable ($nsxmgrsys.cpuInfoDto | select capacity,freeCapacity,totalNoOfCPUs,usedCapacity,usedPercentage) 
$rpt += Get-HtmlContentTable ($nsxmgrsys.memInfoDto | select freeMemory,totalMemory,usedMemory,usedPercentage) 
$rpt += Get-HtmlContentTable ($nsxmgrsys.storageInfoDto | select freeStorage,totalStorage,usedPercentage,usedStorage)
$rpt += Get-HtmlContentTable ($nsxmgrsys.versionInfo | select buildNumber,majorVersion,MinorVersion,patchVersion)
$rpt += Get-HtmlContenttext -Heading "System Component"
$rpt += Get-HtmlContentTable ($nsxmgrcom.componentsByGroup.entry.GetEnumerator().components.component | select componentGroup,componentId,description,enabled,name,status)
$rpt += Get-HtmlContenttext -Heading "Sso Config"
$rpt += Get-HtmlContentTable ($nsxmgrsso | select vsmSolutionName,ssoLookupServiceUrl,ssoAdminUsername,Connected)
$rpt += Get-HtmlContenttext -Heading "vCenter Config"
$rpt += Get-HtmlContentTable ($nsxmgrvCenter | select ipAddress,userName,CertificateThumbprint,assignRoleToUser,vcInventoryLastUpdateTime,Connected)
$rpt += Get-HtmlContenttext -Heading "Syslog Server"
$rpt += Get-HtmlContentTable ($nsxmgrsyslog | select syslogServer,port,protocol)
$rpt += Get-HtmlContenttext -Heading "Time Settings Ntp Server" -Detail ($nsxmgrtime.ntpServer.string)
$rpt += Get-HtmlContentTable ($nsxmgrtime | select datetime,timezone)
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
Disconnect-NsxServer

Connect-VIServer -Server 10.182.20.160 -User "vcsadmin@wpp.net" -Password pM0dularc
Connect-NsxServer -NsxServer 10.182.20.180 -Credential $Cred
$nsxmgrsys = Get-NsxManagerSystemSummary
$nsxmgrcom = Get-NsxManagerComponentSummary
$nsxmgrsso = Get-NsxManagerSsoConfig
$nsxmgrvCenter = Get-NsxManagerVcenterConfig
$nsxmgrsyslog = Get-NsxManagerSyslogServer
$nsxmgrtime = Get-NsxManagerTimeSettings
$rpt += Get-HTMLContentOpen -HeaderText "Brazil (LDO) NSX Manager Summary" -IsHidden
$rpt += Get-HtmlContenttext -Heading "System Summary"
$rpt += Get-HtmlContentTable ($nsxmgrsys | select applianceName,currentSystemDate,domainName,hostName,ipv4Address,uptime) 
$rpt += Get-HtmlContentTable ($nsxmgrsys.cpuInfoDto | select capacity,freeCapacity,totalNoOfCPUs,usedCapacity,usedPercentage) 
$rpt += Get-HtmlContentTable ($nsxmgrsys.memInfoDto | select freeMemory,totalMemory,usedMemory,usedPercentage) 
$rpt += Get-HtmlContentTable ($nsxmgrsys.storageInfoDto | select freeStorage,totalStorage,usedPercentage,usedStorage)
$rpt += Get-HtmlContentTable ($nsxmgrsys.versionInfo | select buildNumber,majorVersion,MinorVersion,patchVersion)
$rpt += Get-HtmlContenttext -Heading "System Component"
$rpt += Get-HtmlContentTable ($nsxmgrcom.componentsByGroup.entry.GetEnumerator().components.component | select componentGroup,componentId,description,enabled,name,status)
$rpt += Get-HtmlContenttext -Heading "Sso Config"
$rpt += Get-HtmlContentTable ($nsxmgrsso | select vsmSolutionName,ssoLookupServiceUrl,ssoAdminUsername,Connected)
$rpt += Get-HtmlContenttext -Heading "vCenter Config"
$rpt += Get-HtmlContentTable ($nsxmgrvCenter | select ipAddress,userName,CertificateThumbprint,assignRoleToUser,vcInventoryLastUpdateTime,Connected)
$rpt += Get-HtmlContenttext -Heading "Syslog Server"
$rpt += Get-HtmlContentTable ($nsxmgrsyslog | select syslogServer,port,protocol)
$rpt += Get-HtmlContenttext -Heading "Time Settings Ntp Server" -Detail ($nsxmgrtime.ntpServer.string)
$rpt += Get-HtmlContentTable ($nsxmgrtime | select datetime,timezone)
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
Disconnect-NsxServer

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

#nsx manager Backup#
$rpt += Get-htmlcontentopen -HeaderText "NSX Manager Backup" -IsHidden
$nsxmgrbackupln2 =  (Get-ChildItem \\10.113.48.214\ftp_nsxbkup\ftp_nsxbkup -File | Sort-Object -Descending lastwritetime | where{$_.name -inotmatch "backupproperties"} | select -First 1)
$rpt += Get-HTMLContentOpen -HeaderText "Piller 2 NSX Manager Backup" -IsHidden
$rpt += Get-HTMLContentOpen -HeaderText "London (LN2) NSX Manager Backup" -IsHidden 
$rpt += Get-HtmlContentTable ($nsxmgrbackupln2 | select LastWriteTime,Length,Name)
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
$nsxmgrbackupbr1 =  (Get-ChildItem \\wxbr1pjmp002\NSX_BACKUP\ftp_nsxbkup\ftp_nsxbkup -File | Sort-Object -Descending lastwritetime | where{$_.name -inotmatch "backupproperties"} | select -First 1)
$rpt += Get-HTMLContentOpen -HeaderText "Brazil (BR1) NSX Manager Backup" -IsHidden
$rpt += Get-HtmlContentTable ($nsxmgrbackupbr1 | select LastWriteTime,Length,Name)
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
$nsxmgrbackupsg1 =  (Get-ChildItem \\wxsg1pjmp0002\NSX_BACKUP\ftp_nsxbkup -File | Sort-Object -Descending lastwritetime | where{$_.name -inotmatch "backupproperties"} | select -First 1)
$rpt += Get-HTMLContentOpen -HeaderText "Singapore (SG1) NSX Manager Backup" -IsHidden
$rpt += Get-HtmlContentTable ($nsxmgrbackupsg1 | select LastWriteTime,Length,Name)
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
$nsxmgrbackupwd1 =  (Get-ChildItem \\wxwd1pjmp0002\NSX_BACKUP\ftp_nsxbkup -File | Sort-Object -Descending lastwritetime | where{$_.name -inotmatch "backupproperties"} | select -First 1)
$rpt += Get-HTMLContentOpen -HeaderText "Washington (WD1) NSX Manager Backup" -IsHidden
$rpt += Get-HtmlContentTable ($nsxmgrbackupwd1 | select LastWriteTime,Length,Name)
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
$nsxmgrbackupedo =  (Get-ChildItem \\WXED0PJMP0001\NSX_Backup\FTP_NSXBACKUP -File | Sort-Object -Descending lastwritetime | where{$_.name -inotmatch "backupproperties"} | select -First 1)
$rpt += Get-HTMLContentOpen -HeaderText "Piller 3 NSX Manager Backup" -IsHidden
$rpt += Get-HTMLContentOpen -HeaderText "London (EDO) NSX Manager Backup" -IsHidden
$rpt += Get-HtmlContentTable ($nsxmgrbackupedo | select LastWriteTime,Length,Name)
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
$nsxmgrbackupudo =  (Get-ChildItem \\wxud0pjmp0001\NSX_BACKUP\FTP_NSXBACKUP -File | Sort-Object -Descending lastwritetime | where{$_.name -inotmatch "backupproperties"} | select -First 1)
$rpt += Get-HTMLContentOpen -HeaderText "US Raleigh  (UDO) NSX Manager Backup" -IsHidden
$rpt += Get-HtmlContentTable ($nsxmgrbackupudo | select LastWriteTime,Length,Name)
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
$nsxmgrbackupldo =  (Get-ChildItem \\Wxld0pjmp0001\nsx_backup\NSX_BACKUP -File | Sort-Object -Descending lastwritetime | where{$_.name -inotmatch "backupproperties"} | select -First 1)
$rpt += Get-HTMLContentOpen -HeaderText "Brazil (LDO) NSX Manager Backup" -IsHidden
$rpt += Get-HtmlContentTable ($nsxmgrbackupldo | select LastWriteTime,Length,Name)
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
$nsxmgrbackupado =  (Get-ChildItem \\wxad0pjmp0001\NSX_BACKUP\NSX_BACKUP -File | Sort-Object -Descending lastwritetime | where{$_.name -inotmatch "backupproperties"} | select -First 1)
$rpt += Get-HTMLContentOpen -HeaderText "Singapore (ADO) NSX Manager Backup" -IsHidden
$rpt += Get-HtmlContentTable ($nsxmgrbackupado | select LastWriteTime,Length,Name)
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

# nsx firewall and Netcpad service status)
if (Get-Module -ListAvailable -Name Posh-SSH) { <# do nothing #> }
else { 
    # install the module automatically
    iex (New-Object Net.WebClient).DownloadString("https://urldefense.com/v3/__https://gist.github.com/darkoperator/6152630/raw/c67de4f7cd780ba367cccbc2593f38d18ce6df89/instposhsshdev__;!veOZqkxdC7qJ5A!T58bgDweZOQsVvhovqfTEo2dtwJ7VD8x6hW7w5gZz177Z6zfZVfUM7kw130PUk0XFpg$ ")
 }
Import-Module Posh-SSH
$esxihost = Get-Content H:\Scripts\Enhancement\Enhanced\FirewallandNetcpad\LN2\vmhosts.txt
$username = "wpp\nsxvcadmin"
$password = Get-Content H:\Scripts\Enhancement\Enhanced\FirewallandNetcpad\Credentials.txt | ConvertTo-SecureString
$cred = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $Username, $Password
$ssh = New-SSHSession -ComputerName $esxihost -Credential $cred -AcceptKey
$rpt += Get-htmlcontentopen -HeaderText "NSX Firewall and Netcpad Service Status" -IsHidden
$rpt += Get-HTMLContentOpen -HeaderText "Piller 2 NSX Firewall & Netcpad Service Status " -IsHidden
$rpt += Get-HTMLContentOpen -HeaderText "London (LN2) NSX Firewall & Netcpad Service Status " -IsHidden
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText Running
$rpt += Get-HtmlContenttext -Heading "Firewall Status"
$rpt += Get-HtmlContentTable ($nsxfw = Invoke-SSHCommand -SSHSession $ssh -Command "/etc/init.d/vShield-Stateful-Firewall status"  | where {$_.output -eq "vShield-Stateful-Firewall is running"} | select host, {$_.output}) 
$rpt += Get-HtmlContenttext -Heading "NetCP Status"
$rpt += Get-HtmlContentTable ($nsxnc = Invoke-SSHCommand -SSHSession $ssh -Command "/etc/init.d/netcpad status" | where {$_.output -eq "netCP agent service is running"} | select host, {$_.output}) 
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText NotRunning
$rpt += Get-HtmlContenttext -Heading "Firewall Status"
$rpt += Get-HtmlContentTable ($nsxfw = Invoke-SSHCommand -SSHSession $ssh -Command "/etc/init.d/vShield-Stateful-Firewall status"  | where {$_.output -eq "vShield-Stateful-Firewall is not running"} | select host, {$_.output}) 
$rpt += Get-HtmlContenttext -Heading "NetCP Status"
$rpt += Get-HtmlContentTable ($nsxnc = Invoke-SSHCommand -SSHSession $ssh -Command "/etc/init.d/netcpad status" | where {$_.output -eq "netCP agent service is not running"} | select host, {$_.output}) 
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
$esxihost1 = Get-Content H:\Scripts\Enhancement\Enhanced\FirewallandNetcpad\BR1\vmhosts.txt
$ssh1 = New-SSHSession -ComputerName $esxihost1 -Credential $cred -AcceptKey
$rpt += Get-HTMLContentOpen -HeaderText "Brazil (BR1) NSX Firewall & Netcpad Service Status " -IsHidden
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText Running
$rpt += Get-HtmlContenttext -Heading "Firewall Status"
$rpt += Get-HtmlContentTable ($nsxfw = Invoke-SSHCommand -SSHSession $ssh1 -Command "/etc/init.d/vShield-Stateful-Firewall status"  | where {$_.output -eq "vShield-Stateful-Firewall is running"} | select host, {$_.output}) 
$rpt += Get-HtmlContenttext -Heading "NetCP Status"
$rpt += Get-HtmlContentTable ($nsxnc = Invoke-SSHCommand -SSHSession $ssh1 -Command "/etc/init.d/netcpad status" | where {$_.output -eq "netCP agent service is running"} | select host, {$_.output}) 
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText NotRunning
$rpt += Get-HtmlContenttext -Heading "Firewall Status"
$rpt += Get-HtmlContentTable ($nsxfw = Invoke-SSHCommand -SSHSession $ssh1 -Command "/etc/init.d/vShield-Stateful-Firewall status"  | where {$_.output -eq "vShield-Stateful-Firewall is not running"} | select host, {$_.output}) 
$rpt += Get-HtmlContenttext -Heading "NetCP Status"
$rpt += Get-HtmlContentTable ($nsxnc = Invoke-SSHCommand -SSHSession $ssh1 -Command "/etc/init.d/netcpad status" | where {$_.output -eq "netCP agent service is not running"} | select host, {$_.output}) 
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
$esxihost2 = Get-Content -Path H:\Scripts\Enhancement\Enhanced\FirewallandNetcpad\SG1\vmhosts.txt
$ssh2 = New-SSHSession -ComputerName $esxihost2 -Credential $cred -AcceptKey
$rpt += Get-HTMLContentOpen -HeaderText "Singapore (SG1) NSX Firewall & Netcpad Service Status" -IsHidden
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText Running
$rpt += Get-HtmlContenttext -Heading "Firewall Status"
$rpt += Get-HtmlContentTable ($nsxfw = Invoke-SSHCommand -SSHSession $ssh2 -Command "/etc/init.d/vShield-Stateful-Firewall status"  | where {$_.output -eq "vShield-Stateful-Firewall is running"} | select host, {$_.output}) 
$rpt += Get-HtmlContenttext -Heading "NetCP Status"
$rpt += Get-HtmlContentTable ($nsxnc = Invoke-SSHCommand -SSHSession $ssh2 -Command "/etc/init.d/netcpad status" | where {$_.output -eq "netCP agent service is running"} | select host, {$_.output}) 
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText NotRunning
$rpt += Get-HtmlContenttext -Heading "Firewall Status"
$rpt += Get-HtmlContentTable ($nsxfw = Invoke-SSHCommand -SSHSession $ssh2 -Command "/etc/init.d/vShield-Stateful-Firewall status"  | where {$_.output -eq "vShield-Stateful-Firewall is not running"} | select host, {$_.output}) 
$rpt += Get-HtmlContenttext -Heading "NetCP Status"
$rpt += Get-HtmlContentTable ($nsxnc = Invoke-SSHCommand -SSHSession $ssh2 -Command "/etc/init.d/netcpad status" | where {$_.output -eq "netCP agent service is not running"} | select host, {$_.output}) 
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
$esxihost3 = Get-Content -Path H:\Scripts\Enhancement\Enhanced\FirewallandNetcpad\WD1\vmhosts.txt
$ssh3 = New-SSHSession -ComputerName $esxihost3 -Credential $cred -AcceptKey
$rpt += Get-HTMLContentOpen -HeaderText "Washington (WD1) NSX Firewall & Netcpad Service Status" -IsHidden
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText Running
$rpt += Get-HtmlContenttext -Heading "Firewall Status"
$rpt += Get-HtmlContentTable ($nsxfw = Invoke-SSHCommand -SSHSession $ssh3 -Command "/etc/init.d/vShield-Stateful-Firewall status"  | where {$_.output -eq "vShield-Stateful-Firewall is running"} | select host, {$_.output}) 
$rpt += Get-HtmlContenttext -Heading "NetCP Status"
$rpt += Get-HtmlContentTable ($nsxnc = Invoke-SSHCommand -SSHSession $ssh3 -Command "/etc/init.d/netcpad status" | where {$_.output -eq "netCP agent service is running"} | select host, {$_.output}) 
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText NotRunning
$rpt += Get-HtmlContenttext -Heading "Firewall Status"
$rpt += Get-HtmlContentTable ($nsxfw = Invoke-SSHCommand -SSHSession $ssh3 -Command "/etc/init.d/vShield-Stateful-Firewall status"  | where {$_.output -eq "vShield-Stateful-Firewall is not running"} | select host, {$_.output}) 
$rpt += Get-HtmlContenttext -Heading "NetCP Status"
$rpt += Get-HtmlContentTable ($nsxnc = Invoke-SSHCommand -SSHSession $ssh3 -Command "/etc/init.d/netcpad status" | where {$_.output -eq "netCP agent service is not running"} | select host, {$_.output}) 
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
$esxihost4 = Get-Content -Path H:\Scripts\Enhancement\Enhanced\FirewallandNetcpad\EDO\vmhosts.txt
$ssh4 = New-SSHSession -ComputerName $esxihost4 -Credential $cred -AcceptKey
$rpt += Get-HTMLContentOpen -HeaderText "Piller 3 NSX Firewall & Netcpad Service Status" -IsHidden
$rpt += Get-HTMLContentOpen -HeaderText "London (EDO) NSX Firewall & Netcpad Service Status" -IsHidden
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText Running
$rpt += Get-HtmlContenttext -Heading "Firewall Status"
$rpt += Get-HtmlContentTable ($nsxfw = Invoke-SSHCommand -SSHSession $ssh4 -Command "/etc/init.d/vShield-Stateful-Firewall status"  | where {$_.output -eq "vShield-Stateful-Firewall is running"} | select host, {$_.output}) 
$rpt += Get-HtmlContenttext -Heading "NetCP Status"
$rpt += Get-HtmlContentTable ($nsxnc = Invoke-SSHCommand -SSHSession $ssh4 -Command "/etc/init.d/netcpad status" | where {$_.output -eq "netCP agent service is running"} | select host, {$_.output}) 
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText NotRunning
$rpt += Get-HtmlContenttext -Heading "Firewall Status"
$rpt += Get-HtmlContentTable ($nsxfw = Invoke-SSHCommand -SSHSession $ssh4 -Command "/etc/init.d/vShield-Stateful-Firewall status"  | where {$_.output -eq "vShield-Stateful-Firewall is not running"} | select host, {$_.output}) 
$rpt += Get-HtmlContenttext -Heading "NetCP Status"
$rpt += Get-HtmlContentTable ($nsxnc = Invoke-SSHCommand -SSHSession $ssh4 -Command "/etc/init.d/netcpad status" | where {$_.output -eq "netCP agent service is not running"} | select host, {$_.output}) 
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
$esxihost5 = Get-Content -Path H:\Scripts\Enhancement\Enhanced\FirewallandNetcpad\ADO\vmhosts.txt
$ssh5 = New-SSHSession -ComputerName $esxihost5 -Credential $cred -AcceptKey
$rpt += Get-HTMLContentOpen -HeaderText "Singapore (ADO) NSX Firewall & Netcpad Service Status" -IsHidden
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText Running
$rpt += Get-HtmlContenttext -Heading "Firewall Status"
$rpt += Get-HtmlContentTable ($nsxfw = Invoke-SSHCommand -SSHSession $ssh5 -Command "/etc/init.d/vShield-Stateful-Firewall status"  | where {$_.output -eq "vShield-Stateful-Firewall is running"} | select host, {$_.output}) 
$rpt += Get-HtmlContenttext -Heading "NetCP Status"
$rpt += Get-HtmlContentTable ($nsxnc = Invoke-SSHCommand -SSHSession $ssh5 -Command "/etc/init.d/netcpad status" | where {$_.output -eq "netCP agent service is running"} | select host, {$_.output}) 
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText NotRunning
$rpt += Get-HtmlContenttext -Heading "Firewall Status"
$rpt += Get-HtmlContentTable ($nsxfw = Invoke-SSHCommand -SSHSession $ssh5 -Command "/etc/init.d/vShield-Stateful-Firewall status"  | where {$_.output -eq "vShield-Stateful-Firewall is not running"} | select host, {$_.output}) 
$rpt += Get-HtmlContenttext -Heading "NetCP Status"
$rpt += Get-HtmlContentTable ($nsxnc = Invoke-SSHCommand -SSHSession $ssh5 -Command "/etc/init.d/netcpad status" | where {$_.output -eq "netCP agent service is not running"} | select host, {$_.output}) 
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
$esxihost6 = Get-Content -Path H:\Scripts\Enhancement\Enhanced\FirewallandNetcpad\LDO\vmhosts.txt
$ssh6 = New-SSHSession -ComputerName $esxihost6 -Credential $cred -AcceptKey
$rpt += Get-HTMLContentOpen -HeaderText "Brazil (LDO) NSX Firewall & Netcpad Service Status" -IsHidden
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText Running
$rpt += Get-HtmlContenttext -Heading "Firewall Status"
$rpt += Get-HtmlContentTable ($nsxfw = Invoke-SSHCommand -SSHSession $ssh6 -Command "/etc/init.d/vShield-Stateful-Firewall status"  | where {$_.output -eq "vShield-Stateful-Firewall is running"} | select host, {$_.output}) 
$rpt += Get-HtmlContenttext -Heading "NetCP Status"
$rpt += Get-HtmlContentTable ($nsxnc = Invoke-SSHCommand -SSHSession $ssh6 -Command "/etc/init.d/netcpad status" | where {$_.output -eq "netCP agent service is running"} | select host, {$_.output}) 
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText NotRunning
$rpt += Get-HtmlContenttext -Heading "Firewall Status"
$rpt += Get-HtmlContentTable ($nsxfw = Invoke-SSHCommand -SSHSession $ssh6 -Command "/etc/init.d/vShield-Stateful-Firewall status"  | where {$_.output -eq "vShield-Stateful-Firewall is not running"} | select host, {$_.output}) 
$rpt += Get-HtmlContenttext -Heading "NetCP Status"
$rpt += Get-HtmlContentTable ($nsxnc = Invoke-SSHCommand -SSHSession $ssh6 -Command "/etc/init.d/netcpad status" | where {$_.output -eq "netCP agent service is not running"} | select host, {$_.output}) 
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
$esxihost7 = Get-Content -Path H:\Scripts\Enhancement\Enhanced\FirewallandNetcpad\UDO\vmhosts.txt
$ssh7 = New-SSHSession -ComputerName $esxihost7 -Credential $cred -AcceptKey
$rpt += Get-HTMLContentOpen -HeaderText "US Raleigh (UDO) NSX Firewall & Netcpad Service Status" -IsHidden
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText Running
$rpt += Get-HtmlContenttext -Heading "Firewall Status"
$rpt += Get-HtmlContentTable ($nsxfw = Invoke-SSHCommand -SSHSession $ssh7 -Command "/etc/init.d/vShield-Stateful-Firewall status"  | where {$_.output -eq "vShield-Stateful-Firewall is running"} | select host, {$_.output}) 
$rpt += Get-HtmlContenttext -Heading "NetCP Status"
$rpt += Get-HtmlContentTable ($nsxnc = Invoke-SSHCommand -SSHSession $ssh7 -Command "/etc/init.d/netcpad status" | where {$_.output -eq "netCP agent service is running"} | select host, {$_.output}) 
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText NotRunning
$rpt += Get-HtmlContenttext -Heading "Firewall Status"
$rpt += Get-HtmlContentTable ($nsxfw = Invoke-SSHCommand -SSHSession $ssh7 -Command "/etc/init.d/vShield-Stateful-Firewall status"  | where {$_.output -eq "vShield-Stateful-Firewall is not running"} | select host, {$_.output}) 
$rpt += Get-HtmlContenttext -Heading "NetCP Status"
$rpt += Get-HtmlContentTable ($nsxnc = Invoke-SSHCommand -SSHSession $ssh7 -Command "/etc/init.d/netcpad status" | where {$_.output -eq "netCP agent service is not running"} | select host, {$_.output}) 
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

#Fortigate Backup#
cd 'H:\Scripts\Enhancement\Enhanced\Fortigate'
$London = "5.10.108.52"
$Singapore = "119.81.120.212"
$Washington = "174.37.252.44"
$Brazil = "169.57.253.204"
$date = Get-Date -UFormat "%Y-%m-%d-%A"
$dir = New-Item -ItemType Directory -Name $date
cd $dir
$Username = "Venkateswarlu"
$Password = Get-Content 'H:\Scripts\Enhancement\Enhanced\Fortigate\Credentials.txt' | ConvertTo-SecureString
$cred = New-Object -Typename System.Management.Automation.PSCredential -ArgumentList $Username, $Password
$ssh = New-SSHSession -ComputerName $London -Credential $cred -AcceptKey
$ssh1 = New-SSHSession -ComputerName $Singapore -Credential $cred -AcceptKey
$ssh2 = New-SSHSession -ComputerName $Washington -Credential $cred -AcceptKey
$ssh3 = New-SSHSession -ComputerName $Brazil -Credential $cred -AcceptKey
$data = $(Invoke-SSHCommand -SSHSession $ssh -Command "show full-configuration").output
$data1 = $(Invoke-SSHCommand -SSHSession $ssh1 -Command "show full-configuration").output
$data2= $(Invoke-SSHCommand -SSHSession $ssh2 -Command "show full-configuration").output
$data3 = $(Invoke-SSHCommand -SSHSession $ssh3 -Command "show full-configuration").output
$data | Out-File 'London.conf'
$data1 | Out-File 'Singapore.conf'
$data2 | Out-File 'Washington.conf'
$data3 | Out-File 'Brazil.conf'
$rpt += Get-htmlcontentopen -HeaderText "Fortigate Backup" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Fortigate Files" 
$rpt += Get-HtmlContentTable (Get-ChildItem  | select Name, LastWriteTime,Length)
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
cd\

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

#NSX VPN Status#

$nsxln2 = "10.113.48.204"
$Username = "admin"
$Password = Get-Content H:\Scripts\Enhancement\Enhanced\Credentials.txt | ConvertTo-SecureString
$Cred = New-Object -Typename System.Management.Automation.PSCredential -ArgumentList $Username, $Password
$Pzssword = Get-Content H:\Scripts\Enhancement\Enhanced\zCredentials.txt | ConvertTo-SecureString
$Credz = New-Object -Typename System.Management.Automation.PSCredential -ArgumentList $Username, $Pzssword
Connect-VIServer -Server axln2pvmw0001.wpp.net -User "vcsadmin@wpp.net" -Password pM0dularc
Connect-NsxServer $nsxln2 -Credential $Cred
$NXLN2 = Get-NsxEdge | where{$_.name -match ("NXLN2XESG0001-VPN001")}
$nxln2ipsec = ($NXLN2.features.ipsec.sites.site)
$nxln2channel = (($NXLN2 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nxln2tunnel = (($NXLN2 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-htmlcontentopen -HeaderText "NSX VPN EDGES" -IsHidden
$rpt += Get-HTMLContentOpen -HeaderText "PILLER 2 VPN EDGES" -IsHidden
$rpt += Get-HTMLContentOpen -HeaderText "LN2 VPN EDGES" -IsHidden 
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-02 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nxln2channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nxln2channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nxln2channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nxln2tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nxln2tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nxln2tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-02" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nxln2ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nxln2channel = (($NXLN2 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nxln2channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nxln2tunnel = (($NXLN2 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nxln2tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nxln2tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nxln2tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nxln2tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NKLN2 = Get-NsxEdge | where{$_.name -match ("NKLN2XESG0001-VPN001")}
$nkln2ipsec = ($NKLN2.features.ipsec.sites.site)
$nkln2channel = (($NKLN2 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nkln2tunnel = (($NKLN2 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-09 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nkln2channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nkln2channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nkln2channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ($nkln2tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nkln2tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nkln2tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-09" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nkln2ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nkln2channel = (($NKLN2 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nkln2channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nkln2tunnel = (($NKLN2 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nkln2tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nkln2tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nkln2tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nkln2tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NYLN2 = Get-NsxEdge | where{$_.name -match ("NYLN2XESG0001-VPN001")}
$nyln2ipsec = ($NYLN2.features.ipsec.sites.site)
$nyln2channel = (($NYLN2 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nyln2tunnel = (($NYLN2 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-14 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nyln2channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nyln2channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nyln2channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ($nyln2tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nyln2tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nyln2tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-14" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nyln2ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nyln2channel = (($NYLN2 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nyln2channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nyln2tunnel = (($NYLN2 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nyln2tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nyln2tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nyln2tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nyln2tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NJLN2 = Get-NsxEdge | where{$_.name -match ("NLNJ2XESG0001-VPN001")}
$njln2ipsec = ($NJLN2.features.ipsec.sites.site)
$njln2channel = (($NJLN2 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$njln2tunnel = (($NJLN2 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-19 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($njln2channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($njln2channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($njln2channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ($njln2tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($njln2tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($njln2tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-19" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($njln2ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$njln2channel = (($NJLN2 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($njln2channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$njln2tunnel = (($NJLN2 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($njln2tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($njln2tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($njln2tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($njln2tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NGLN2 = Get-NsxEdge | where{$_.name -match ("NGLN2XESG0001-VPN001")}
$ngln2ipsec = ($NGLN2.features.ipsec.sites.site)
$ngln2channel = (($NGLN2 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$ngln2tunnel = (($NGLN2 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-24 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($ngln2channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($ngln2channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($ngln2channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ($ngln2tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($ngln2tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($ngln2tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-24" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($ngln2ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$ngln2channel = (($NGLN2 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($ngln2channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$ngln2tunnel = (($NGLN2 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($ngln2tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($ngln2tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($ngln2tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($ngln2tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NMLN2 = Get-NsxEdge | where{$_.name -match ("NMLN2XESG0001-VPN001")}
$nmln2ipsec = ($NMLN2.features.ipsec.sites.site)
$nmln2channel = (($NMLN2 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nmln2tunnel = (($NMLN2 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-29 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nmln2channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nmln2channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nmln2channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ($nmln2tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nmln2tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nmln2tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-29" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nmln2ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nmln2channel = (($NMLN2 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nmln2channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nmln2tunnel = (($NMLN2 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nmln2tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nmln2tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nmln2tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nmln2tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage


$NOLN2 = Get-NsxEdge | where{$_.name -match ("NOLN2XESG0001-VPN001")}
$noln2ipsec = ($NOLN2.features.ipsec.sites.site)
$noln2channel = (($NOLN2 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$noln2tunnel = (($NOLN2 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-36 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($noln2channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($noln2channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($noln2channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ($noln2tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($noln2tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($noln2tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-36" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($noln2ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$noln2channel = (($NOLN2 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($noln2channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$noln2tunnel = (($NOLN2 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($noln2tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($noln2tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($noln2tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($noln2tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NHLN2 = Get-NsxEdge | where{$_.name -match ("NHLN2XESG0001-VPN001")}
$nhln2ipsec = ($NHLN2.features.ipsec.sites.site)
$nhln2channel = (($NHLN2 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nhln2tunnel = (($NHLN2 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-41 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nhln2channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nhln2channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nhln2channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ($nhln2tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nhln2tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nhln2tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-41" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nhln2ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nhln2channel = (($NHLN2 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nhln2channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nhln2tunnel = (($NHLN2 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nhln2tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nhln2tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nhln2tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nhln2tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NILN2 = Get-NsxEdge | where{$_.name -match ("NILN2XESG0001-VPN001")}
$niln2ipsec = ($NILN2.features.ipsec.sites.site)
$niln2channel = (($NILN2 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$niln2tunnel = (($NILN2 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-46 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($niln2channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($niln2channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($niln2channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ($niln2tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($niln2tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($niln2tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-46" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($niln2ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$niln2channel = (($NILN2 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($niln2channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$niln2tunnel = (($NILN2 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($niln2tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($niln2tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($niln2tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($niln2tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NPLN2 = Get-NsxEdge | where{$_.name -match ("NPLN2XESG0001-VPN001")}
$npln2ipsec = ($NPLN2.features.ipsec.sites.site)
$npln2channel = (($NPLN2 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$npln2tunnel = (($NPLN2 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-51 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($npln2channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($npln2channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($npln2channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ($npln2tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($npln2tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($npln2tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-51" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($npln2ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$npln2channel = (($NPLN2 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($npln2channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$npln2tunnel = (($NPLN2 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($npln2tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($npln2tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($npln2tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($npln2tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
Disconnect-NsxServer

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

#BR1 VPN#

$nsxbr1 = "10.150.33.9"
$Username = "admin"
$Password = Get-Content H:\Scripts\Enhancement\Enhanced\Credentials.txt | ConvertTo-SecureString
$Cred = New-Object -Typename System.Management.Automation.PSCredential -ArgumentList $Username, $Password
$Pzssword = Get-Content H:\Scripts\Enhancement\Enhanced\zCredentials.txt | ConvertTo-SecureString
$Credz = New-Object -Typename System.Management.Automation.PSCredential -ArgumentList $Username, $Pzssword
Connect-VIServer -Server 10.150.33.6 -User "vcsadmin@wpp.net" -Password pM0dularc
Connect-NsxServer $nsxbr1 -Credential $Cred
$NXBR1 = Get-NsxEdge | where{$_.name -match ("NXBR1XESG0001-VPN001")}
$nxbr1ipsec = ($NXBR1.features.ipsec.sites.site)
$nxbr1channel = (($NXBR1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nxbr1tunnel = (($NXBR1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HTMLContentOpen -HeaderText "BR1 VPN EDGES" -IsHidden 
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-06 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nxbr1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nxbr1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nxbr1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nxbr1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nxbr1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nxbr1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-06" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nxbr1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nxbr1channel = (($NXBR1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nxbr1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nxbr1tunnel = (($NXBR1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nxbr1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nxbr1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nxbr1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nxbr1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NYBR1 = Get-NsxEdge | where{$_.name -match ("NYBR1XESG0001-VPN001")}
$nybr1ipsec = ($NYBR1.features.ipsec.sites.site)
$nybr1channel = (($NYBR1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nybr1tunnel = (($NYBR1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-13 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nybr1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nybr1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nybr1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ($nybr1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nybr1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nybr1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-13" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nybr1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nybr1channel = (($NYBR1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nybr1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nybr1tunnel = (($NYBR1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nybr1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nybr1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nybr1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nybr1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NJBR1 = Get-NsxEdge | where{$_.name -match ("NJBR1XESG0001-VPN001")}
$njbr1ipsec = ($NJBR1.features.ipsec.sites.site)
$njbr1channel = (($NJBR1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$njbr1tunnel = (($NJBR1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-18 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($njbr1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($njbr1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($njbr1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ($njbr1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($njbr1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($njbr1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-18" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($njbr1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$njbr1channel = (($NJBR1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($njbr1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$njbr1tunnel = (($NJBR1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($njbr1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($njbr1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($njbr1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($njbr1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NGBR1 = Get-NsxEdge | where{$_.name -match ("NGBR1XESG0001-VPN001")}
$ngbr1ipsec = ($NGBR1.features.ipsec.sites.site)
$ngbr1channel = (($NGBR1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$ngbr1tunnel = (($NGBR1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-23 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($ngbr1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($ngbr1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($ngbr1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ($ngbr1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($ngbr1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($ngbr1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-23" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($ngbr1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$ngbr1channel = (($NGBR1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($ngbr1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$ngbr1tunnel = (($NGBR1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($ngbr1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($ngbr1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($ngbr1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($ngbr1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NMBR1 = Get-NsxEdge | where{$_.name -match ("NMBR1XESG0001-VPN001")}
$nmbr1ipsec = ($NMBR1.features.ipsec.sites.site)
$nmbr1channel = (($NMBR1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nmbr1tunnel = (($NMBR1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-28 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nmbr1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nmbr1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nmbr1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ($nmbr1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nmbr1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nmbr1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-28" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nmbr1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nmbr1channel = (($NMBR1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nmbr1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nmbr1tunnel = (($NMBR1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nmbr1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nmbr1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nmbr1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nmbr1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NKBR1 = Get-NsxEdge | where{$_.name -match ("NKBR1XESG0001-VPN001")}
$nkbr1ipsec = ($NKBR1.features.ipsec.sites.site)
$nkbr1channel = (($NKBR1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nkbr1tunnel = (($NKBR1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-35 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nkbr1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nkbr1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nkbr1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ($nkbr1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nkbr1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nkbr1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-35" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nkbr1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nkbr1channel = (($NKBR1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nkbr1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nkbr1tunnel = (($NKBR1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nkbr1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nkbr1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nkbr1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nkbr1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage


$NOBR1 = Get-NsxEdge | where{$_.name -match ("NOBR1XESG0001-VPN001")}
$nobr1ipsec = ($NOBR1.features.ipsec.sites.site)
$nobr1channel = (($NOBR1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nobr1tunnel = (($NOBR1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-40 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nobr1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nobr1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nobr1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ($nobr1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nobr1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nobr1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-40" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nobr1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nobr1channel = (($NOBR1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nobr1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nobr1tunnel = (($NOBR1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nobr1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nobr1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nobr1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nobr1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NHBR1 = Get-NsxEdge | where{$_.name -match ("NHBR1XESG0001-VPN001")}
$nhbr1ipsec = ($NHBR1.features.ipsec.sites.site)
$nhbr1channel = (($NHBR1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nhbr1tunnel = (($NHBR1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-45 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nhbr1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nhbr1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nhbr1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ($nhbr1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nhbr1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nhbr1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-45" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nhbr1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nhbr1channel = (($NHBR1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nhbr1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nhbr1tunnel = (($NHBR1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nhbr1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nhbr1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nhbr1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nhbr1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NIBR1 = Get-NsxEdge | where{$_.name -match ("NIBR1XESG0001-VPN001")}
$nibr1ipsec = ($NIBR1.features.ipsec.sites.site)
$nibr1channel = (($NIBR1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nibr1tunnel = (($NIBR1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-50 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nibr1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nibr1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nibr1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ($nibr1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nibr1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nibr1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-50" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nibr1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nibr1channel = (($NIBR1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nibr1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nibr1tunnel = (($NIBR1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nibr1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nibr1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nibr1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nibr1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NPBR1 = Get-NsxEdge | where{$_.name -match ("NPBR1XESG0001-VPN001")}
$npbr1ipsec = ($NPBR1.features.ipsec.sites.site)
$npbr1channel = (($NPBR1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$npbr1tunnel = (($NPBR1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-56 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($npbr1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($npbr1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($npbr1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ($npbr1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($npbr1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($npbr1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-56" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($npbr1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$npbr1channel = (($NPBR1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($npbr1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$npbr1tunnel = (($NPBR1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($npbr1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($npbr1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($npbr1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($npbr1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
Disconnect-NsxServer

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

#SG1 VPN#

$nsxsg1 = "10.117.167.140"
$Username = "admin"
$Pzssword = Get-Content H:\Scripts\Enhancement\Enhanced\zCredentials.txt | ConvertTo-SecureString
$Credz = New-Object -Typename System.Management.Automation.PSCredential -ArgumentList $Username, $Pzssword
Connect-VIServer -Server 10.117.167.136 -User "vcsadmin@wpp.net" -Password pM0dularc
Connect-NsxServer $nsxsg1 -Credential $Credz
$NXSG1 = Get-NsxEdge | where{$_.name -match ("NXSG1XESG0001-VPN001")}
$nxsg1ipsec = ($NXSG1.features.ipsec.sites.site)
$nxsg1channel = (($NXSG1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nxsg1tunnel = (($NXSG1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HTMLContentOpen -HeaderText "SG1 VPN EDGES" -IsHidden 
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-02 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nxsg1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nxsg1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nxsg1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nxsg1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nxsg1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nxsg1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-02" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nxsg1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nxsg1channel = (($NXSG1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nxsg1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nxsg1tunnel = (($NXSG1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nxsg1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nxsg1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nxsg1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nxsg1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NYSG1 = Get-NsxEdge | where{$_.name -match ("NYSG1XESG0001-VPN001")}
$nysg1ipsec = ($NYSG1.features.ipsec.sites.site)
$nysg1channel = (($NYSG1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nysg1tunnel = (($NYSG1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-09 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nysg1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nysg1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nysg1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nysg1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nysg1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nysg1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-09" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nysg1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nysg1channel = (($NYSG1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nysg1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nysg1tunnel = (($NYSG1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nysg1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nysg1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nysg1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nysg1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NJSG1 = Get-NsxEdge | where{$_.name -match ("NJSG1XESG0001-VPN001")}
$njsg1ipsec = ($NJSG1.features.ipsec.sites.site)
$njsg1channel = (($NJSG1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$njsg1tunnel = (($NJSG1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-14 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($njsg1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($njsg1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($njsg1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $njsg1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($njsg1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($njsg1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-14" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($njsg1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$njsg1channel = (($NJSG1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($njsg1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$njsg1tunnel = (($NJSG1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($njsg1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($njsg1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($njsg1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($njsg1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NGSG1 = Get-NsxEdge | where{$_.name -match ("NGSG1XESG0001-VPN001")}
$ngsg1ipsec = ($NGSG1.features.ipsec.sites.site)
$ngsg1channel = (($NGSG1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$ngsg1tunnel = (($NGSG1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-20 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($ngsg1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($ngsg1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($ngsg1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $ngsg1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($ngsg1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($ngsg1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-20" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($ngsg1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$ngsg1channel = (($NGSG1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($ngsg1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$ngsg1tunnel = (($NGSG1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($ngsg1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($ngsg1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($ngsg1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($ngsg1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NMSG1 = Get-NsxEdge | where{$_.name -match ("NMSG1XESG0001-VPN001")}
$nmsg1ipsec = ($NMSG1.features.ipsec.sites.site)
$nmsg1channel = (($NMSG1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nmsg1tunnel = (($NMSG1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-26 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nmsg1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nmsg1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nmsg1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nmsg1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nmsg1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nmsg1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-26" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nmsg1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nmsg1channel = (($NMSG1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nmsg1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nmsg1tunnel = (($NMSG1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nmsg1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nmsg1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nmsg1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nmsg1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NKSG1 = Get-NsxEdge | where{$_.name -match ("NKSG1XESG0001-VPN001")}
$nksg1ipsec = ($NKSG1.features.ipsec.sites.site)
$nksg1channel = (($NKSG1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nksg1tunnel = (($NKSG1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-31 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nksg1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nksg1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nksg1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nksg1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nksg1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nksg1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-31" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nksg1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nksg1channel = (($NKSG1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nksg1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nksg1tunnel = (($NKSG1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nksg1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nksg1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nksg1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nksg1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage


$NOSG1 = Get-NsxEdge | where{$_.name -match ("NOSG1XESG0001-VPN001")}
$nosg1ipsec = ($NOSG1.features.ipsec.sites.site)
$nosg1channel = (($NOSG1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nosg1tunnel = (($NOSG1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-36 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nosg1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nosg1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nosg1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nosg1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nosg1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nosg1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-36" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nosg1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nosg1channel = (($NOSG1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nosg1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nosg1tunnel = (($NOSG1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nosg1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nosg1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nosg1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nosg1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NISG1 = Get-NsxEdge | where{$_.name -match ("NISG1XESG0001-VPN001")}
$nisg1ipsec = ($NISG1.features.ipsec.sites.site)
$nisg1channel = (($NISG1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nisg1tunnel = (($NISG1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-41 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nisg1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nisg1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nisg1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nisg1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nisg1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nisg1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-41" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nisg1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nisg1channel = (($NISG1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nisg1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nisg1tunnel = (($NISG1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nisg1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nisg1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nisg1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nisg1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NHSG1 = Get-NsxEdge | where{$_.name -match ("NHSG1XESG0001-VPN001")}
$nhsg1ipsec = ($NHSG1.features.ipsec.sites.site)
$nhsg1channel = (($NHSG1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nhsg1tunnel = (($NHSG1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-46 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nhsg1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nhsg1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nhsg1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nhsg1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nhsg1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nhsg1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-46" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nhsg1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nhsg1channel = (($NHSG1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nhsg1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nhsg1tunnel = (($NHSG1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nhsg1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nhsg1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nhsg1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nhsg1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage


$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NPSG1 = Get-NsxEdge | where{$_.name -match ("NPSG1XESG0001-VPN001")}
$npsg1ipsec = ($NPSG1.features.ipsec.sites.site)
$npsg1channel = (($NPSG1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$npsg1tunnel = (($NPSG1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-51 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($npsg1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($npsg1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($npsg1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $npsg1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($npsg1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($npsg1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-51" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($npsg1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$npsg1channel = (($NPSG1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($npsg1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$npsg1tunnel = (($NPSG1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($npsg1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($npsg1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($npsg1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($npsg1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
Disconnect-NsxServer

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

#WD1 VPN#

$nsxwd1 = "10.125.127.76"
$Username = "admin"
$Pzssword = Get-Content H:\Scripts\Enhancement\Enhanced\zCredentials.txt | ConvertTo-SecureString
$Credz = New-Object -Typename System.Management.Automation.PSCredential -ArgumentList $Username, $Pzssword
Connect-VIServer -Server 10.125.127.72 -User "vcsadmin@wpp.net" -Password pM0dularc
Connect-NsxServer $nsxwd1 -Credential $Credz
$NXWD1 = Get-NsxEdge | where{$_.name -match ("NXWD1XESG0001-VPN001")}
$nxwd1ipsec = ($NXWD1.features.ipsec.sites.site)
$nxwd1channel = (($NXWD1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nxwd1tunnel = (($NXWD1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HTMLContentOpen -HeaderText "WD1 VPN EDGES" -IsHidden 
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-06 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nxwd1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nxwd1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nxwd1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nxwd1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nxwd1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nxwd1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-06" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nxwd1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nxwd1channel = (($NXWD1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nwd1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nxwd1tunnel = (($NXWD1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nxwd1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nxwd1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nxwd1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nxwd1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NYWD1 = Get-NsxEdge | where{$_.name -match ("NYWD1XESG0001-VPN001")}
$nywd1ipsec = ($NYWD1.features.ipsec.sites.site)
$nywd1channel = (($NYWD1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nywd1tunnel = (($NYWD1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-10 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nywd1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nywd1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nywd1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nywd1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nywd1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nywd1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-10" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nywd1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nywd1channel = (($NYWD1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nyd1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nywd1tunnel = (($NYWD1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nywd1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nywd1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nywd1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nywd1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NJWD1 = Get-NsxEdge | where{$_.name -match ("NJWD1XESG0001-VPN001")}
$njwd1ipsec = ($NJWD1.features.ipsec.sites.site)
$njwd1channel = (($NJWD1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$njwd1tunnel = (($NJWD1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-17 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($njwd1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($njwd1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($njwd1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $njwd1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($njwd1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($njwd1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-17" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($njwd1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$njwd1channel = (($NJWD1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($njd1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$njwd1tunnel = (($NJWD1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($njwd1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($njwd1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($njwd1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($njwd1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NGWD1 = Get-NsxEdge | where{$_.name -match ("NGWD1XESG0001-VPN001")}
$ngwd1ipsec = ($NGWD1.features.ipsec.sites.site)
$ngwd1channel = (($NGWD1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$ngwd1tunnel = (($NGWD1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-21 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($ngwd1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($ngwd1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($ngwd1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $ngwd1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($ngwd1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($ngwd1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-21" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($ngwd1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$ngwd1channel = (($NGWD1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($ngd1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$ngwd1tunnel = (($NGWD1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($ngwd1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($ngwd1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($ngwd1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($ngwd1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NMWD1 = Get-NsxEdge | where{$_.name -match ("NMWD1XESG0001-VPN001")}
$nmwd1ipsec = ($NMWD1.features.ipsec.sites.site)
$nmwd1channel = (($NMWD1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nmwd1tunnel = (($NMWD1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-27 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nmwd1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nmwd1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nmwd1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nmwd1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nmwd1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nmwd1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-27" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nmwd1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nmwd1channel = (($NMWD1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nmd1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nmwd1tunnel = (($NMWD1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nmwd1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nmwd1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nmwd1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nmwd1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NKWD1 = Get-NsxEdge | where{$_.name -match ("NKWD1XESG0001-VPN001")}
$nkwd1ipsec = ($NKWD1.features.ipsec.sites.site)
$nkwd1channel = (($NKWD1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nkwd1tunnel = (($NKWD1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-34 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nkwd1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nkwd1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nkwd1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nkwd1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nkwd1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nkwd1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-34" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nkwd1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nkwd1channel = (($NKWD1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nkd1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nkwd1tunnel = (($NKWD1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nkwd1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nkwd1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nkwd1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nkwd1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NOWD1 = Get-NsxEdge | where{$_.name -match ("NOWD1XESG0001-VPN001")}
$nowd1ipsec = ($NOWD1.features.ipsec.sites.site)
$nowd1channel = (($NOWD1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nowd1tunnel = (($NOWD1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-39 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nowd1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nowd1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nowd1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nowd1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nowd1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nowd1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-39" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nowd1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nowd1channel = (($NOWD1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nod1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nowd1tunnel = (($NOWD1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nowd1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nowd1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nowd1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nowd1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NHWD1 = Get-NsxEdge | where{$_.name -match ("NHWD1XESG0001-VPN001")}
$nhwd1ipsec = ($NHWD1.features.ipsec.sites.site)
$nhwd1channel = (($NHWD1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nhwd1tunnel = (($NHWD1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-44 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nhwd1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nhwd1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nhwd1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nhwd1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nhwd1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nhwd1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-44" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nhwd1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nhwd1channel = (($NHWD1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nhd1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nhwd1tunnel = (($NHWD1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nhwd1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nhwd1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nhwd1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nhwd1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NIWD1 = Get-NsxEdge | where{$_.name -match ("NIWD1XESG0001-VPN001")}
$niwd1ipsec = ($NIWD1.features.ipsec.sites.site)
$niwd1channel = (($NIWD1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$niwd1tunnel = (($NIWD1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-49 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($niwd1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($niwd1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($niwd1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $niwd1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($niwd1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($niwd1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-49" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($niwd1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$niwd1channel = (($NIWD1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nid1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$niwd1tunnel = (($NIWD1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($niwd1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($niwd1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($niwd1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($niwd1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NPWD1 = Get-NsxEdge | where{$_.name -match ("NPWD1XESG0001-VPN001")}
$npwd1ipsec = ($NPWD1.features.ipsec.sites.site)
$npwd1channel = (($NPWD1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$npwd1tunnel = (($NPWD1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-55 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($npwd1channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($npwd1channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($npwd1channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $npwd1tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($npwd1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($npwd1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-55" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($npwd1ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$npwd1channel = (($NPWD1 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($npd1channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$npwd1tunnel = (($NPWD1 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($npwd1tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($npwd1tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($npwd1tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($npwd1tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage


#P3 VPN Edge#

$nsxed0 = "10.172.20.180"
$Username = "admin"
$Password = Get-Content H:\Scripts\Enhancement\Enhanced\Credentials.txt | ConvertTo-SecureString
$Cred = New-Object -Typename System.Management.Automation.PSCredential -ArgumentList $Username, $Password
Connect-VIServer -Server 10.172.20.160 -User "vcsadmin@wpp.net" -Password pM0dularc
Connect-NsxServer $nsxed0 -Credential $Cred
$NKED0 = Get-NsxEdge | where{$_.name -match ("NKED0XESG0001-VPN001")}
$nked0ipsec = ($NKED0.features.ipsec.sites.site)
$nked0channel = (($NKED0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nked0tunnel = (($NKED0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-htmlcontentopen -HeaderText "PILLER 3 VPN EDGES" -IsHidden
$rpt += Get-HTMLContentOpen -HeaderText "EDO VPN EDGES" -IsHidden 
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-11 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nked0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nked0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nked0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nked0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nked0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nked0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-11" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nked0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nked0channel = (($NKED0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nked0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nked0tunnel = (($NKED0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nked0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nked0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nked0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nked0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NGED0 = Get-NsxEdge | where{$_.name -match ("NGED0XESG0001-VPN001")}
$nged0ipsec = ($NGED0.features.ipsec.sites.site)
$nged0channel = (($NGED0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nged0tunnel = (($NGED0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-17 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nged0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nged0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nged0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nged0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nged0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nged0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-17" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nged0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nged0channel = (($NGED0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nged0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nged0tunnel = (($NGED0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nged0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nged0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nged0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nged0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NJED0 = Get-NsxEdge | where{$_.name -match ("NJED0XESG0001-VPN001")}
$njed0ipsec = ($NJED0.features.ipsec.sites.site)
$njed0channel = (($NJED0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$njed0tunnel = (($NJED0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-22 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($njed0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($njed0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($njed0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $njed0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($njed0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($njed0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-22" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($njed0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$njed0channel = (($NJED0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($njed0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$njed0tunnel = (($NJED0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($njed0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($njed0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($njed0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($njed0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NMED0 = Get-NsxEdge | where{$_.name -match ("NMED0XESG0001-VPN001")}
$nmed0ipsec = ($NMED0.features.ipsec.sites.site)
$nmed0channel = (($NMED0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nmed0tunnel = (($NMED0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-27 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nmed0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nmed0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nmed0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nmed0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nmed0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nmed0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-27" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nmed0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nmed0channel = (($NMED0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nmed0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nmed0tunnel = (($NMED0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nmed0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nmed0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nmed0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nmed0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NOED0 = Get-NsxEdge | where{$_.name -match ("NOED0XESG0001-VPN001")}
$noed0ipsec = ($NOED0.features.ipsec.sites.site)
$noed0channel = (($NOED0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$noed0tunnel = (($NOED0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-32 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($noed0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($noed0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($noed0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $noed0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($noed0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($noed0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-32" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($noed0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$noed0channel = (($NOED0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($noed0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$noed0tunnel = (($NOED0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($noed0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($noed0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($noed0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($noed0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NYED0 = Get-NsxEdge | where{$_.name -match ("NYED0XESG0001-VPN001")}
$nyed0ipsec = ($NYED0.features.ipsec.sites.site)
$nyed0channel = (($NYED0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nyed0tunnel = (($NYED0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-39 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nyed0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nyed0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nyed0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nyed0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nyed0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nyed0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-39" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nyed0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nyed0channel = (($NYED0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nyed0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nyed0tunnel = (($NYED0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nyed0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nyed0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nyed0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nyed0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NIED0 = Get-NsxEdge | where{$_.name -match ("NIED0XESG0001-VPN001")}
$nied0ipsec = ($NIED0.features.ipsec.sites.site)
$nied0channel = (($NIED0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nied0tunnel = (($NIED0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-50 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nied0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nied0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nied0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nied0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nied0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nied0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-50" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nied0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nied0channel = (($NIED0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nied0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nied0tunnel = (($NIED0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nied0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nied0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nied0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nied0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NHED0 = Get-NsxEdge | where{$_.name -match ("NHED0XESG0001-VPN001")}
$nhed0ipsec = ($NHED0.features.ipsec.sites.site)
$nhed0channel = (($NHED0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nhed0tunnel = (($NHED0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-55 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nhed0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nhed0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nhed0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nhed0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nhed0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nhed0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-55" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nhed0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nhed0channel = (($NHED0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nhed0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nhed0tunnel = (($NHED0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nhed0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nhed0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nhed0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nhed0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NPED0 = Get-NsxEdge | where{$_.name -match ("NPED0XESG0001-VPN001")}
$nped0ipsec = ($NPED0.features.ipsec.sites.site)
$nped0channel = (($NPED0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nped0tunnel = (($NPED0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-61 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nped0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nped0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nped0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nped0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nped0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nped0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-61" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nped0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nped0channel = (($NPED0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nped0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nped0tunnel = (($NPED0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nped0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nped0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nped0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nped0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

#ADO VPN#

$nsxad0 = "10.186.20.180"
$Username = "admin"
$Password = Get-Content H:\Scripts\Enhancement\Enhanced\Credentials.txt | ConvertTo-SecureString
$Cred = New-Object -Typename System.Management.Automation.PSCredential -ArgumentList $Username, $Password
Connect-VIServer -Server 10.186.20.160 -User "vcsadmin@wpp.net" -Password pM0dularc
Connect-NsxServer $nsxad0 -Credential $Cred
$NOAD0 = Get-NsxEdge | where{$_.name -match ("NOAD0XESG0001-VPN001")}
$noad0ipsec = ($NOAD0.features.ipsec.sites.site)
$noad0channel = (($NOAD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$noad0tunnel = (($NOAD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HTMLContentOpen -HeaderText "ADO VPN EDGES" -IsHidden 
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-26 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($noad0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($noad0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($noad0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $noad0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($noad0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($noad0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-26" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($noad0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$noad0channel = (($NOAD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($noad0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$noad0tunnel = (($NOAD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($noad0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($noad0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($noad0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($noad0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NKAD0 = Get-NsxEdge | where{$_.name -match ("NKAD0XESG0001-VPN001")}
$nkad0ipsec = ($NKAD0.features.ipsec.sites.site)
$nkad0channel = (($NKAD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nkad0tunnel = (($NKAD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-27 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nkad0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nkad0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nkad0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nkad0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nkad0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nkad0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-27" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nkad0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nkad0channel = (($NKAD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nkad0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nkad0tunnel = (($NKAD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nkad0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nkad0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nkad0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nkad0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NIAD0 = Get-NsxEdge | where{$_.name -match ("NIAD0XESG0001-VPN001")}
$niad0ipsec = ($NIAD0.features.ipsec.sites.site)
$niad0channel = (($NIAD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$niad0tunnel = (($NIAD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-28 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($niad0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($niad0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($niad0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $niad0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($niad0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($niad0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-28" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($niad0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$niad0channel = (($NIAD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($niad0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$niad0tunnel = (($NIAD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($niad0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($niad0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($niad0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($niad0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NHAD0 = Get-NsxEdge | where{$_.name -match ("NHAD0XESG0001-VPN001")}
$nhad0ipsec = ($NHAD0.features.ipsec.sites.site)
$nhad0channel = (($NHAD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nhad0tunnel = (($NHAD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-29 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nhad0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nhad0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nhad0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nhad0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nhad0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nhad0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-29" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nhad0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nhad0channel = (($NHAD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nhad0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nhad0tunnel = (($NHAD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nhad0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nhad0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nhad0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nhad0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NGAD0 = Get-NsxEdge | where{$_.name -match ("NGAD0XESG0001-VPN001")}
$ngad0ipsec = ($NGAD0.features.ipsec.sites.site)
$ngad0channel = (($NGAD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$ngad0tunnel = (($NGAD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-31 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($ngad0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($ngad0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($ngad0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $ngad0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($ngad0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($ngad0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-31" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($ngad0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$ngad0channel = (($NGAD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($ngad0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$ngad0tunnel = (($NGAD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($ngad0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($ngad0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($ngad0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($ngad0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NJAD0 = Get-NsxEdge | where{$_.name -match ("NJAD0XESG0001-VPN001")}
$njad0ipsec = ($NJAD0.features.ipsec.sites.site)
$njad0channel = (($NJAD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$njad0tunnel = (($NJAD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-35 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($njad0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($njad0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($njad0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $njad0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($njad0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($njad0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-35" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($njad0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$njad0channel = (($NJAD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($njad0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$njad0tunnel = (($NJAD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($njad0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($njad0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($njad0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($njad0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NYAD0 = Get-NsxEdge | where{$_.name -match ("NYAD0XESG0001-VPN001")}
$nyad0ipsec = ($NYAD0.features.ipsec.sites.site)
$nyad0channel = (($NYAD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nyad0tunnel = (($NYAD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-40 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nyad0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nyad0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nyad0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nyad0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nyad0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nyad0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-40" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nyad0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nyad0channel = (($NYAD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nyad0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nyad0tunnel = (($NYAD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nyad0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nyad0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nyad0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nyad0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NMAD0 = Get-NsxEdge | where{$_.name -match ("NMAD0XESG0001-VPN001")}
$nmad0ipsec = ($NMAD0.features.ipsec.sites.site)
$nmad0channel = (($NMAD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nmad0tunnel = (($NMAD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-45 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nmad0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nmad0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nmad0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nmad0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nmad0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nmad0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-45" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nmad0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nmad0channel = (($NMAD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nmad0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nmad0tunnel = (($NMAD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nmad0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nmad0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nmad0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nmad0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

#UDO VPN#

$nsxud0 = "10.176.20.180"
$Username = "admin"
$Password = Get-Content H:\Scripts\Enhancement\Enhanced\Credentials.txt | ConvertTo-SecureString
$Cred = New-Object -Typename System.Management.Automation.PSCredential -ArgumentList $Username, $Password
Connect-VIServer -Server 10.176.20.160 -User "vcsadmin@wpp.net" -Password pM0dularc
Connect-NsxServer $nsxud0 -Credential $Cred
$NGUD0 = Get-NsxEdge | where{$_.name -match ("NGUD0XESG0001-VPN001")}
$ngud0ipsec = ($NGUD0.features.ipsec.sites.site)
$ngud0channel = (($NGUD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$ngud0tunnel = (($NGUD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HTMLContentOpen -HeaderText "UDO VPN EDGES" -IsHidden 
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-11 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($ngud0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($ngud0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($ngud0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $ngud0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($ngud0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($ngud0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-11" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($ngud0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$ngud0channel = (($NGUD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($ngud0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$ngud0tunnel = (($NGUD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($ngud0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($ngud0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($ngud0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($ngud0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NMUD0 = Get-NsxEdge | where{$_.name -match ("NMUD0XESG0001-VPN001")}
$nmud0ipsec = ($NMUD0.features.ipsec.sites.site)
$nmud0channel = (($NMUD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nmud0tunnel = (($NMUD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-13 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nmud0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nmud0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nmud0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nmud0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nmud0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nmud0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-13" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nmud0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nmud0channel = (($NMUD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nmud0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nmud0tunnel = (($NMUD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nmud0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nmud0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nmud0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nmud0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NIUD0 = Get-NsxEdge | where{$_.name -match ("NIUD0XESG0001-VPN001")}
$niud0ipsec = ($NIUD0.features.ipsec.sites.site)
$niud0channel = (($NIUD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$niud0tunnel = (($NIUD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-20 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($niud0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($niud0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($niud0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $niud0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($niud0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($niud0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-20" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($niud0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$niud0channel = (($NIUD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($niud0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$niud0tunnel = (($NIUD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($niud0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($niud0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($niud0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($niud0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NOUD0 = Get-NsxEdge | where{$_.name -match ("NOUD0XESG0001-VPN001")}
$noud0ipsec = ($NOUD0.features.ipsec.sites.site)
$noud0channel = (($NOUD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$noud0tunnel = (($NOUD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-25 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($noud0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($noud0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($noud0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $noud0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($noud0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($noud0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-25" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($noud0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$noud0channel = (($NOUD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($noud0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$noud0tunnel = (($NOUD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($noud0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($noud0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($noud0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($noud0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NHUD0 = Get-NsxEdge | where{$_.name -match ("NHUD0XESG0001-VPN001")}
$nhud0ipsec = ($NHUD0.features.ipsec.sites.site)
$nhud0channel = (($NHUD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nhud0tunnel = (($NHUD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-30 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nhud0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nhud0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nhud0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nhud0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nhud0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nhud0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-30" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nhud0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nhud0channel = (($NHUD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nhud0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nhud0tunnel = (($NHUD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nhud0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nhud0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nhud0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nhud0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NYUD0 = Get-NsxEdge | where{$_.name -match ("NYUD0XESG0001-VPN001")}
$nyud0ipsec = ($NYUD0.features.ipsec.sites.site)
$nyud0channel = (($NYUD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nyud0tunnel = (($NYUD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-31 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nyud0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nyud0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nyud0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nyud0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nyud0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nyud0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-31" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nyud0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nyud0channel = (($NYUD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nyud0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nyud0tunnel = (($NYUD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nyud0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nyud0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nyud0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nyud0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NKUD0 = Get-NsxEdge | where{$_.name -match ("NKUD0XESG0001-VPN001")}
$nkud0ipsec = ($NKUD0.features.ipsec.sites.site)
$nkud0channel = (($NKUD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nkud0tunnel = (($NKUD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-36 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nkud0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nkud0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nkud0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nkud0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nkud0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nkud0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-36" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nkud0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nkud0channel = (($NKUD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nkud0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nkud0tunnel = (($NKUD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nkud0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nkud0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nkud0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nkud0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

#LDO VPN#

$nsxld0 = "10.182.20.180"
$Username = "admin"
$Password = Get-Content H:\Scripts\Enhancement\Enhanced\Credentials.txt | ConvertTo-SecureString
$Cred = New-Object -Typename System.Management.Automation.PSCredential -ArgumentList $Username, $Password
Connect-VIServer -Server 10.182.20.160 -User "vcsadmin@wpp.net" -Password pM0dularc
Connect-NsxServer $nsxld0 -Credential $Cred
$NYLD0 = Get-NsxEdge | where{$_.name -match ("NYLD0XESG0001-VPN001")}
$nyld0ipsec = ($NYLD0.features.ipsec.sites.site)
$nyld0channel = (($NYLD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nyld0tunnel = (($NYLD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HTMLContentOpen -HeaderText "LDO VPN EDGES" -IsHidden 
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-09 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nyld0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nyld0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nyld0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nyld0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nyld0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nyld0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-09" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nyld0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nyld0channel = (($NYLD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nyld0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nyld0tunnel = (($NYLD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nyld0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nyld0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nyld0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nyld0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NGLD0 = Get-NsxEdge | where{$_.name -match ("NGLD0XESG0001-VPN001")}
$ngld0ipsec = ($NGLD0.features.ipsec.sites.site)
$ngld0channel = (($NGLD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$ngld0tunnel = (($NGLD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-14 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($ngld0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($ngld0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($ngld0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $ngld0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($ngld0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($ngld0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-14" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($ngld0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$ngld0channel = (($NGLD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($ngld0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$ngld0tunnel = (($NGLD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($ngld0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($ngld0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($ngld0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($ngld0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NHLD0 = Get-NsxEdge | where{$_.name -match ("NHLD0XESG0001-VPN001")}
$nhld0ipsec = ($NHLD0.features.ipsec.sites.site)
$nhld0channel = (($NHLD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nhld0tunnel = (($NHLD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-19 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nhld0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nhld0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nhld0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nhld0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nhld0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nhld0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-19" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nhld0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nhld0channel = (($NHLD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nhld0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nhld0tunnel = (($NHLD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nhld0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nhld0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nhld0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nhld0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NKLD0 = Get-NsxEdge | where{$_.name -match ("NKLD0XESG0001-VPN001")}
$nkld0ipsec = ($NKLD0.features.ipsec.sites.site)
$nkld0channel = (($NKLD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nkld0tunnel = (($NKLD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-24 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nkld0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nkld0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nkld0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nkld0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nkld0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nkld0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-24" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nkld0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nkld0channel = (($NKLD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nkld0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nkld0tunnel = (($NKLD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nkld0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nkld0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nkld0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nkld0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NJLD0 = Get-NsxEdge | where{$_.name -match ("NJLD0XESG0001-VPN001")}
$njld0ipsec = ($NJLD0.features.ipsec.sites.site)
$njld0channel = (($NJLD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$njld0tunnel = (($NJLD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-29 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($njld0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($njld0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($njld0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $njld0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($njld0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($njld0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-29" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($njld0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$njld0channel = (($NJLD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($njld0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$njld0tunnel = (($NJLD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($njld0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($njld0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($njld0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($njld0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NOLD0 = Get-NsxEdge | where{$_.name -match ("NOLD0XESG0001-VPN001")}
$nold0ipsec = ($NOLD0.features.ipsec.sites.site)
$nold0channel = (($NOLD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nold0tunnel = (($NOLD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-34 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nold0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nold0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nold0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nold0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nold0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nold0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-34" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nold0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nold0channel = (($NOLD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nold0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nold0tunnel = (($NOLD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nold0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nold0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nold0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nold0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NILD0 = Get-NsxEdge | where{$_.name -match ("NILD0XESG0001-VPN001")}
$nild0ipsec = ($NILD0.features.ipsec.sites.site)
$nild0channel = (($NILD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nild0tunnel = (($NILD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-36 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nild0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nild0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nild0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nild0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nild0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nild0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-36" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nild0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nild0channel = (($NILD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nild0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nild0tunnel = (($NILD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nild0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nild0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nild0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nild0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage


$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$NMLD0 = Get-NsxEdge | where{$_.name -match ("NMLD0XESG0001-VPN001")}
$nmld0ipsec = ($NMLD0.features.ipsec.sites.site)
$nmld0channel = (($NMLD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$nmld0tunnel = (($NMLD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += Get-HtmlContentOpen -HeaderText "EDGE-43 Summary Information" -IsHidden
$rpt += Get-HtmlContenttext -Heading "Total Channel" -Detail ($nmld0channel.channelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Channel Status" -Detail ("Up " + ($nmld0channel | ? {$_.channelstatus -eq 'up'} | measure ).count + " / Down " + ($nmld0channel | ? {$_.channelstatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContenttext -Heading "Total Tunnel" -Detail ( $nxed0tunnel.tunnelstatus.count)
$rpt += Get-HtmlContenttext -Heading "Tunnel Status" -Detail ("Up " + ($nxed0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nxed0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HTMLContentOpen -HeaderText "EDGE-43" -IsHidden
$rpt += Get-HtmlContenttext -Heading "IPSec VPN"
$rpt += Get-HtmlContentTable ($nmld0ipsec | select enabled,name,localId,localIp,peerId,peerIp)
$nmld0channel = (($NMLD0 | Get-NsxIPsecStats).siteStatistics.ikeStatus)
$rpt += Get-HtmlContenttext -Heading "Channel status"
$rpt += Get-HtmlContentTable ($nmld0channel | select channelStatus,channelState,localIpAddress,peerId,peerIpAddress,{$_.peerSubnets.string})
$nmld0tunnel = (($NMLD0 | Get-NsxIPsecStats).siteStatistics.tunnelStats)
$rpt += get-HtmlColumn1of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText up
$rpt += Get-HtmlContenttext -Heading "Tunnel status" -Detail ("Up " + ($nmld0tunnel | ? {$_.tunnelStatus -eq 'up'} | measure ).count + " / Down " + ($nmld0tunnel | ? {$_.tunnelStatus -eq 'down'} | measure ).count)
$rpt += Get-HtmlContentTable ($nmld0tunnel | where {$_.tunnelStatus -eq "up"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += get-htmlColumn2of2
$rpt += Get-HtmlContentOpen -BackgroundShade 1 -HeaderText down
$rpt += Get-HtmlContenttext -Heading "Tunnel status"
$rpt += Get-HtmlContentTable ($nmld0tunnel | where {$_.tunnelStatus -eq "down"} | select tunnelStatus,tunnelState,localSubnet,peerSubnet,establishedDate)
$rpt += Get-HtmlContentClose
$rpt += get-htmlColumnClose
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage

$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
$rpt += Get-HtmlContentClose
$rpt += Get-HTMLClosePage
$rpt += Get-HTMLClosePage -FooterText "Created by Nandeesh Muniyappa" 

Test-Report -TestName WPP
#Invoke-Item $ReportOutputPath
Set-Location "H:\Scripts\Enhancement\Enhanced\Htmlreport"
$files = Get-ChildItem | sort LastWriteTime -Descending | select -First 1
$res =@("Venkateswarlu Macharla <venkmach@in.ibm.com>", "Indronil Chatterjee <chatindr@in.ibm.com>", "Appalanaidu Penki <apppenki@in.ibm.com>", "Appalla V Balanagendra <balaappalla@in.ibm.com>", "Nandeesh Muniyappa1 <nmuniyap@in.ibm.com>", "Ajit S Rajput <ajit.rajput@in.ibm.com>", "Asheesh Gali <ashegali@in.ibm.com>", "Hari ramachandran <hramach4@in.ibm.com>")
Send-MailMessage -To $res -From NSX-Health-Check@script.com -SMTPServer 10.172.30.18 -Subject “NSX Daily Health check HTML Report_$(Get-Date -UFormat "%Y-%m-%d-%A")” -Body “Attached file has Status details of all NSX daily health check report in HTML format” -Attachments $files
