﻿Import-Module VMware.PowerCLI
cd "D:\CloudOps\DSCluster-CapcityReport"

$password = Get-Content .\pass.txt | ConvertTo-SecureString -Key (Get-Content .\aes.key)
$credential = New-Object System.Management.Automation.PsCredential("Dsglobal.org\S705979",$password)

$filename = get-date -format yyyy-MM-ddTHH-mm-ss
$to = @("TRB, R. (Rangarajan) <Rangarajan.TRB@voya.com>")
$cc = @("DL-Cloud-Ops@voya.com")
$start = Get-Date

$report = @()
$vcenters = @()
$vcenters = "Mvcewvvc9701","Jvcewvvc9702"

foreach ($vcenter in $vcenters){

Connect-VIServer $vcenter -Credential $credential
Write-Host "Connected $vcenter" -ForegroundColor Yellow
$DSClus = get-view -ViewType Storagepod | where {$_.ChildEntity.Count -gt 0}
cls
$DSClus.Count

foreach ($DSC in $DSClus)
{
$vmCount = (Get-DatastoreCluster -Name $dsc.name | Get-VM).count
if($vmCount -ne 0){
$Data =  "" | select DC,Name,CapacityTB,FreeTB,UsageTB,ComputeCluster,Vcenter
$Data.Name = $dsc.Name
$text = $dsc.Client.ServiceUrl
$Data.CapacityTB = [math]::Round(($DSC.Summary.Capacity /1TB),2)
$Data.FreeTB = [math]::Round(($dsc.Summary.FreeSpace / 1TB),2)
$Data.UsageTB = [math]::Round(($Data.CapacityTB - $data.FreeTB),2)
$ds = Get-View $DSC.ChildEntity
$hosts = $ds.host.key | select -Unique

switch ($vcenter){
"Mvcewvvc9700" {
$data.dc = "MPL"
}
"Jvcewvvc9700" {
$data.dc = "Jax"
}
"Mvcewvvc9701" {
$dc = $hosts | select -First 1
$dc =  (get-view $dc).name.substring(1,3)
$data.dc = $dc.toupper()}
"Jvcewvvc9702" {
$dc = $hosts | select -First 1
$dc =  (get-view $dc).name.substring(1,3)
$data.dc = $dc.toupper()
}
default {

$dc = $vcenter.substring(1,3)
$data.dc = $dc.toupper()

}
}


$clus = (Get-View $Hosts).parent | select -Unique
$Data.ComputeCluster = (Get-View $clus).Name -join ','
$Data.vcenter = $text.Substring($text.IndexOf('//')+2).split('/')[0]
$report += $Data
$Data
}
}

#cls
#$global:DefaultVIServers 

#sleep -Seconds 5
$global:DefaultVIServers | % {write-host " Disconnecting $_" ; Disconnect-VIServer $_ -Confirm:$false}

}

$end = Get-Date
$Time = New-TimeSpan -Start $start -End $end
$Info = "VMware Weekly DS Cluster Report `n Regards, `n Cloud Ops Team"
$report | Export-Csv -path .\"DSClus-$filename.csv" -UseCulture -NoTypeInformation
$file = Get-ChildItem | where {$_.Name -match "DSClus-$filename.csv"}
Send-MailMessage -To 'Hari.subramanian@voya.com' -From "WeeklyDSclusReport@voya.com"  -Subject "Weekly DS cluster $filename" -Attachments $file -Body "$time `n`n Please find the Weekly datastore Cluster Report" -SmtpServer smtp1.dsglobal.org

