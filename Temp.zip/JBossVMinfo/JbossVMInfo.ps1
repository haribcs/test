﻿

Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Confirm:$false -ErrorAction SilentlyContinue | Out-Null
Import-Module VMware.PowerCLI


$password = Get-Content .\pass.txt | ConvertTo-SecureString -Key (Get-Content .\aes.key)
$credential = New-Object System.Management.Automation.PsCredential("Dsglobal.org\S705979",$password)

$filename = get-date -format yyyy-MM-ddTHH-mm-ss
$to = @("SanAdmin@voya.com","Rudolph, J. (James) <James.Rudolph@voya.com>")
$cc = @("DL-Cloud-Ops@voya.com")
$start = Get-Date



Connect-VIServer jvcewvvc9702,mvcewvvc9701 -Credential $credential
$clusters = Get-Cluster *jboss* -ErrorAction SilentlyContinue
$report = @()
foreach ($clus in $clusters) {
$Servers = $clus | Get-VMHost -State Connected
foreach ($esxi in $Servers)
{
$data = "" | select Cluster,Datacenter,IP,CPUModel,CPUSpeed,HTAvailbale,HTActive,HostCPU,CoresperCPU,NoOfCores
$data.Cluster = $clus.name
$data.Datacenter = ($clus | Get-Datacenter).Name
$data.IP = (Get-VMHostNetworkAdapter -VMHost $esxi | where Name -eq 'vmk0').IP
$data.CPUModel = $esxi.ProcessorType
$data.CPUSpeed =  $esxi.ProcessorType.split('@')[1]
$data.HTAvailbale = "True"
$data.HTActive = $esxi.HyperthreadingActive
$data.HostCPU = $esxi.ExtensionData.Hardware.CpuInfo.NumCpuPackages
$data.NoOfCores = $esxi.ExtensionData.Hardware.CpuInfo.NumCpuCores
$data.CoresperCPU = [int] ($data.NoOfCores / $data.HostCPU)

$vms = $esxi | Get-VM | select Name,PowerState,@{N='UsedSpace GB';E={[math]::Round(($_.usedspaceGB),2)}},MemoryGB,NumCpu,@{N='Host';E={$esxi.Name}},@{N='IP';E={$data.IP}},@{N='Datacenter';E={$data.Datacenter}},@{N='Cluster';E={$clus.Name}},@{N='CPU Model';E={$data.CPUModel}},@{N='Speed';E={$data.CPUSpeed}},@{N='HTAvilable';E={$data.HTAvailbale}},@{N='HT Active';E={$data.HTActive}},@{N='No of CPU';E={$data.HostCPU}},@{N='Cores per CPU';E={$data.CoresperCPU}},@{N='No of Cores';E={$data.NoOfCores}}
$vms | ft -AutoSize
$report += $vms

}
}

#$report | Export-Csv .\Jboss.csv -UseCulture -NoTypeInformation

$Time = New-TimeSpan -Start $start -End $end
$Info = "Jboss Monthly Vms Report `n Regards, `n Cloud Ops Team"
$report | Export-Csv -Path .\"JbossVMsreport-$filename.csv" -UseCulture -NoTypeInformation
$end = Get-Date
$file = Get-ChildItem | where {$_.Name -match "$filename.csv"}
Send-MailMessage -To 'Hari.subramanian@voya.com' -From "JbossMonthlyReport@voya.com" -Cc $cc -Subject "Jboss Monthly Report $filename" -Attachments $file -Body "$info `n $time"-SmtpServer smtp1.dsglobal.org

