﻿Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Confirm:$false | Out-Null
Import-Module VMware.PowerCLI,ImportExcel | Out-Null
cd D:\CloudOps\WeeklysnapshotReport
$report =@()
$password = Get-Content .\pass.txt | ConvertTo-SecureString -Key (Get-Content .\aes.key)
$credential = New-Object System.Management.Automation.PsCredential("Dsglobal.org\S705979",$password)

$filename = get-date -format yyyy-MM-ddTHH-mm-ss
$SourceExcel = "D:\CloudOps\WeeklysnapshotReport\SnapshotReport-$filename.xlsx"
Connect-VIServer mvcewvvc9701,jvcewvvc9702,astravce9001,dstravce9001,pmplavvc9100 -Credential $credential
$report = Get-Snapshot (Get-VM) -ErrorAction Ignore |where {($_.Name -ne "initial") -and ($_.Created -le ((Get-Date).AddDays(-7))) } | select vm,Name,Description,Created,IsCurrent,@{N='Snapshot SizeGB';E={[math]::Round($_.sizeGB,2)}},@{N='Vcenter';E={$_.uid.split('@')[1].split(':')[0]}}
 $global:DefaultVIServers | % {Disconnect-VIServer $_ -Confirm:$false}
$report | Export-Excel -Path $SourceExcel -WorksheetName "SnapshotList" -AutoFilter
 $file = Get-ChildItem | where {$_.Name -match "$filename.xlsx"}
 Send-MailMessage -To 'dl-cloud-ops@voya.com' -From WeeklySnapshotReport@voya.com -Subject "WeeklySnapshot $filename" -SmtpServer smtp1.dsglobal.org -Attachments $file 