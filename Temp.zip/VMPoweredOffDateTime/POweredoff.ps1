$rep = @()
$rep = Get-VM | where PowerState -eq 'Poweredoff' | select Name,PowerState,VMHost,@{N='VC';E={$_.uid.split('@')[1].split(':')[0]}},@{Label='poweredOffTime'; Expression={
        $_ | Get-VIEvent -Types Info | 
            Where-Object -Property fullformattedmessage -Match 'shutdown|powered off' | 
            Sort-Object -Property CreatedTime | 
            Select-Object -Last 1 -ExpandProperty CreatedTime 
    }}

$rep | export-csv .\Poweredoff.csv -useculture -NoTypeInformation