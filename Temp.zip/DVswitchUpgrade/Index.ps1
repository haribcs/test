﻿#Import-Module VMware.PowerCLI

#Connect-VIServer jvcewvvc9702,mvcewvvc9701
#$VDSwitch =
$VDVersion = "6.6.0"


foreach ($vdswitch in (Get-VDSwitch | where {($_.Name -ne "DatabaseCluster") -and ($_.version -ne "6.6.0")}))
{

$Cluster = $vdswitch | Get-VMHost | Get-Cluster
$Cluster | ft -AutoSize
Write-Host "chnaging the cluster to Manual" -ForegroundColor Yellow
$Cluster | Set-Cluster -DrsAutomationLevel Manual -Confirm:$false


    Get-VDSwitch -Name $VDSwitch | Export-VDSwitch -Description "My Backup" -Destination ".\PathToBackup\VDSBackup-$VDswitch-$((Get-Date).ToString(‘yyyy-MM-dd-hh-mm’)).zip"
    Get-VDSwitch -Name $VDSwitch | Set-VDSwitch -Version $VDVersion
    Write-Host "Upgrade is complete. Setting Cluster to Fully Automated" -ForegroundColor "Green"
    $Cluster | Set-Cluster -DrsAutomationLevel FullyAutomated -Confirm:$false
 }

