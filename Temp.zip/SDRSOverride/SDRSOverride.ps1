﻿#$clus =  Get-View -ViewType StoragePod -Filter @{"Name"="Pstrwin_G15k2_ECR"}

foreach ($clus in (Get-View -ViewType Storagepod)){
$pod = New-Object VMware.Vim.ManagedObjectReference
$pod.Type = 'StoragePod'
$pod.Value = $clus.MoRef.Value

$spec = New-Object VMware.Vim.StorageDrsConfigSpec
$spec.VmConfigSpec = New-Object VMware.Vim.StorageDrsVmConfigSpec[] ($clus.PodStorageDrsEntry.StorageDrsConfig.VmConfig.Count)


for ($i=0; $i -lt $Clus.PodStorageDrsEntry.StorageDrsConfig.VmConfig.count;$i++){
$spec.VmConfigSpec[$i] = New-Object VMware.Vim.StorageDrsVmConfigSpec
$spec.VmConfigSpec[$i].Operation = 'add'
$spec.VmConfigSpec[$i].Info = New-Object VMware.Vim.StorageDrsVmConfigInfo
$spec.VmConfigSpec[$i].Info.Vm = New-Object VMware.Vim.ManagedObjectReference
$spec.VmConfigSpec[$i].Info.Vm.Type = 'VirtualMachine'
$spec.VmConfigSpec[$i].Info.Vm.Value = $clus.PodStorageDrsEntry.StorageDrsConfig.VmConfig.Vm[$i].value

}
$modify = $true
$_this = Get-View -Id 'StorageResourceManager-StorageResourceManager'
$_this.ConfigureStorageDrsForPod_Task($pod, $spec, $modify)

}