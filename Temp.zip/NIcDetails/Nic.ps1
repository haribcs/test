﻿$report = @()
foreach ($esx in (Get-VMHost)){
$data = "" | select Name,cluster,Description,Speed
$data.Name = $esx.name
$data.cluster = $esx.parent
$esxcli = Get-EsxCli -VMHost $esx
$temp = $esxcli.network.nic.list() | where LinkStatus -eq "Up" | select -First 1
$data.Description = $temp.description
$data.Speed = $temp.speed
$data | ft -AutoSize
$report += $data
}
$report | export-csv -path .\Hostnic.csv -useculture -NotypeInformation