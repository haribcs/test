﻿$rep = @()
cd D:\CloudOps\QlogicHBA\
foreach ($server in (get-vmhost PSTR*,PSHK*)){
$esxcli = Get-EsxCli -VMHost $server
$data = $esxcli.software.vib.list() | where Name -Match "powerpath"| select Name,version,InstallDate,@{N='Esxi';E={$server.name}},@{N='Cluster';E={$server.Parent}}

if ($data -ne $null){
$data | ft -AutoSize
$rep += $data
}

}

$rep | Export-Csv .\Data123456.csv -UseCulture -NoTypeInformation

