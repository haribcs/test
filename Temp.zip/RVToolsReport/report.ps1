﻿[string]$vcpass = "_RVToolsPWDRd6MW4YkyxD5F+h5ub02EYCTQpwedTAHFo2VWKsw8ZN6hcp+xl8q2L3RHOLqrLud"
[string]$vcuser = "Dsglobal.org\S705979"
$vcenters = "astravce9001","dstravce9001","pmplavvc9100","mvcewvvc9701","jvcewvvc9702"
cd D:\CloudOps\RVToolsReport
$date = get-date -format yyyy-MM-ddTHH-mm-ss
New-Item -ItemType Directory -Name $date
cd .\$date
foreach ($vc in $vcenters)
{
[string]$loc = pwd
[string]$file = "$vc-Rvtoolsreport-$date.xlsx"
$Arguments = "-u $vcuser -p $vcpass -s $vc -c ExportAll2xlsx -d $loc -f $file -DBColumnNames -ExcludeCustomAnnotations"

Write-Host $Arguments

$Process = Start-Process -FilePath "C:\Program Files (x86)\Robware\RVTools\RVTools.exe" -ArgumentList $Arguments -NoNewWindow -Wait -PassThru

if($Process.ExitCode -eq -1)
{
    Write-Host "Error: Export failed! RVTools returned exitcode -1, probably a connection error! Script is stopped" -ForegroundColor Red
    exit 1
}


}