#This script is used to disable mks.enable3d to all the virtual machines in a list
#
#Connect to vCenters
#Connect-VIServer jvcewvvc9702.dsglobal.org,mvcewvvc9701.dsglobal.org -Credential (Get-Credential -Message "Please Enter vcenter Credentials")
# get info from CSV.   Format - column1 label (Server)  
$csv=import-csv D:\CloudOps\Disable3D\TestFile.csv
# loop   
foreach ($vm in $csv) {   
     #get VM objects
     $getVM = Get-vm $vm.Server

     if ($getVM.PowerState -eq "Poweredon"){
     if ($getVM.ExtensionData.Guest.ToolsRunningStatus -ne "guestToolsNotRunning"){
     Write-Host "Shutting down $getVM"
     Shutdown-VMGuest -VM $getVM -Confirm:$false
     do {
     Write-Host "Waiting for vms to be shutdown and sleeping for 5 seconds"
     sleep -Seconds 5
     
     }while($getVM.PowerState -eq "Poweredon")
     Get-VM -Name $getVM | New-AdvancedSetting -Name "mks.enable3d" -value $false -Force -Confirm:$false
     
     Start-VM $getVM
     }else{
     Write-Host "Powering the vm as tools is not running" -ForegroundColor Yellow
     Stop-VM $getVM -Confirm:$false
     sleep -Seconds 5
     Get-VM -Name $getVM | New-AdvancedSetting -Name "mks.enable3d" -value $false -Force -Confirm:$false
     Start-VM $getVM
     }

     }else{
     Get-VM -Name $getVM | New-AdvancedSetting -Name "mks.enable3d" -value $false -Force -Confirm:$false
     }
     <#

     #These are the changes recommeneded to disable mks.enable3d
     Get-VM -Name $getVM | New-AdvancedSetting -Name "mks.enable3d" -value $false -Force -Confirm:$false
          If ( $ToolsStatus -eq "toolsNotInstalled" ) { 
          Stop-VM -VM $getVM -Confirm:$false
          #or do i just do Restart-VM -VM
          } Else {
     Shutdown-VMGuest -VM $getVM -Confirm:$false
        #or do i just do Restart-VMGuest -VM
          } 
    #Start VM
    Start-VM -VM $getVM -Confirm:$false
    #>
    
}