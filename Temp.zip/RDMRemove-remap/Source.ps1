﻿Function Replace-VM-RDM {

param($vmname, $scsiid, $rdmname, $filename)

<#

Convert the SCSI address in to Vmware format

#>

$scsicontroller=$null

$scsiid_split=$null

$scsiid_split=$scsiid.split(":")

$scsicontroller=($scsiid_split[0])

# VMware SCSI controller ID in gui is one number higher than the actual controller id

$scsicontroller=[int]$scsicontroller+1

# Vmware expects a conntroller id with 4 chars

$scsicontroller=($scsicontroller.ToString())+"000"

$scsicontroller

# SCSI LUN

$scsilun=$null

# VMware SCSI LUN ID in gui is one number higher than the actual lun id

$scsilun=[int]($scsiid_split[1])#+1

###

$vm = Get-VM -Name "$vmname" | Get-View

IF (!($filename)){

$RDMFile=$rdmname.split(" ")[0]+"_RDM.vmdk"

$filename=(($vm.Config.Files.VmPathName).Replace("$vmname.vmx","$RDMFile"))

}

$esx = Get-View $vm.Runtime.Host

<#

Get CanonicalName for RDM LUN

#>

$rdmCanonicalName=$null

$rdmCanonicalName=(($esx.Config.StorageDevice.ScsiLun | where {$_.DisplayName -eq $rdmname}).CanonicalName)

$rdmDevicePath=(($esx.Config.StorageDevice.ScsiLun | where {$_.DisplayName -eq $rdmname}).DevicePath)

foreach($dev in $vm.Config.Hardware.Device){

    if(($dev.gettype()).Name -eq "VirtualDisk"){

        if(($dev.Backing.CompatibilityMode -eq "physicalMode") -or

        ($dev.Backing.CompatibilityMode -eq "virtualMode")){

            if (($dev.ControllerKey -eq "$scsicontroller") -and ($dev.UnitNumber -eq "$scsilun")) {

                # Remove Harddisk

                $hd=get-harddisk $vm.name | where {$_.Filename -eq $dev.Backing.FileName}

                $hd | remove-harddisk -confirm:$false -DeletePermanently

                Write-Host "Filename: "$dev.backing.fileName

                Write-Host "Disk Mode: "$dev.backing.diskMode

                $dev.backing.deviceName

                $dev.backing.lunUuid

                $DevKey=$dev.key

                $CapacityInKB=$dev.CapacityInKB

                <#$fileMgr = Get-View (Get-View ServiceInstance).Content.fileManager

                $datacenter = (Get-View (Get-VM $VMname | Get-Datacenter).ID).get_MoRef()

                foreach($disk in $vm.LayoutEx.Disk){

                    if($disk.Key -eq $dev.Key){

                    foreach($chain in $disk.Chain){

                        foreach($file in $chain.FileKey){

                            $name = $vm.LayoutEx.File[$file].Name

                            $fileMgr.DeleteDatastoreFile_Task($name, $datacenter)

                            }

                        }

                    continue

                    }

                }#>

            }

        }

        Elseif (($dev.ControllerKey -eq "$scsicontroller") -and ($dev.UnitNumber -eq "$scsilun")) {Write-Host "Selected SCSI Address [$scsiid] is not a RDM"}

    }

}

#$hd1 = New-HardDisk -VM $vmname -DeviceName $rdmDevicePath -DiskType RawPhysical # this line works

    $spec=$null

    $spec = New-Object VMware.Vim.VirtualMachineConfigSpec

    $spec.deviceChange = New-Object VMware.Vim.VirtualDeviceConfigSpec[] (1)

    $spec.deviceChange[0] = New-Object VMware.Vim.VirtualDeviceConfigSpec

    # Create vmdk file

    $spec.deviceChange[0].fileOperation = "create"

    $spec.deviceChange[0].operation = "add"

    $spec.deviceChange = New-Object VMware.Vim.VirtualDeviceConfigSpec[] (1)

    $spec.deviceChange[0] = New-Object VMware.Vim.VirtualDeviceConfigSpec

    $spec.deviceChange[0].operation = "add"

    $spec.deviceChange[0].fileOperation = "create"

    $spec.deviceChange[0].device = New-Object VMware.Vim.VirtualDisk

    $spec.deviceChange[0].device.key = -100

    $spec.deviceChange[0].device.backing = New-Object VMware.Vim.VirtualDiskRawDiskMappingVer1BackingInfo

    $spec.deviceChange[0].device.backing.fileName = "$filename"

    $spec.deviceChange[0].device.backing.deviceName = (($esx.Config.StorageDevice.ScsiLun | where {$_.DisplayName -eq $rdmname}).DevicePath)

    $spec.deviceChange[0].device.backing.compatibilityMode = "physicalMode"

    $spec.deviceChange[0].device.backing.diskMode = ""

    $spec.deviceChange[0].device.connectable = New-Object VMware.Vim.VirtualDeviceConnectInfo

    $spec.deviceChange[0].device.connectable.startConnected = $true

    $spec.deviceChange[0].device.connectable.allowGuestControl = $false

    $spec.deviceChange[0].device.connectable.connected = $true

# SCSI controller device key

    $spec.deviceChange[0].device.controllerKey = [int]$scsicontroller

# The UnitNUmber SCSIID 7 is reserved for the Controller - so skip to 8.

    if ($scsilun -eq 6) {$scsilun = $scsilun + 1}

# Take next unit number for HD

    $spec.deviceChange[0].device.unitnumber = [int]$scsilun

    $spec.deviceChange[0].device.capacityInKB = [int]$CapacityInKB

    $vm = Get-View (Get-VM $VMname).ID

    $vm.ReconfigVM($spec)

}

Replace-VM-RDM $vmname $scsiid $rdmname $filename