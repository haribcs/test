﻿



#$allTagAssociationMethodSVC = Get-CisService com.vmware.cis.tagging.tag_association

$testVM | %{

#Get-View -ViewType VirtualMachine -Filter @{"Name"=$_.Entity}


$VMInfo = (Get-View -ViewType VirtualMachine -Filter @{"Name"=$_.Entity}).MoRef
$vmid = New-Object PSObject -Property @{
id = $VMInfo.value
type = $VMInfo.Type
}

# The Tagging Service uses tag IDs, not names, so get the ID from the name using the method above.
#$tagId = Get-TagIdFromName($tagName)
Write-Host "Assiging tag for $_.Entity" -ForegroundColor Yellow
# Now attach the tag to the VM.
$allTagAssociationMethodSVC.attach($_.uid, $vmid)

}


