﻿cd D:\CloudOps\CIMCSNMPupdate
#Import-Module Cisco.IMC
$report = @()
$cred = Get-Credential
foreach ($imc in (Get-Content .\hosts.txt)){
Connect-Imc $imc -Credential $cred | out-null
#Write-Host "Connected $imc" -ForegroundColor Green
$data = Get-ImcSnmpTrap -Id 1
$data | ft -AutoSize
$report += $data
<#
if(((Get-ImcSnmp).AdminState) -ne "enabled"){
Set-ImcSnmp -AdminState enabled -Confirm:$false
Write-Host "SNMp enabled on $imc" -ForegroundColor Yellow
Add-ImcSnmpTrap -Id 1 -Hostname "10.170.233.15" -AdminState "enabled" -Version v2c -NotificationType traps -Port 162
Write-Host "SNMp Trap is enabled for $imc" -ForegroundColor Yellow
}
#>
Disconnect-Imc | out-null
}
