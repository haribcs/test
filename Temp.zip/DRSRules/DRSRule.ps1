﻿Import-Module VMware.PowerCLI,DRSRule,ImportExcel
cd D:\CloudOps\DRSRules
$password = Get-Content .\pass.txt | ConvertTo-SecureString -Key (Get-Content .\aes.key)
$credential = New-Object System.Management.Automation.PsCredential("Dsglobal.org\S705979",$password)

$filename = get-date -format yyyy-MM-ddTHH-mm-ss
$SourceExcel = "D:\CloudOps\DRSRules\DRSRules-$filename.xlsx"

$ErrorActionPreference = “silentlycontinue”
$report = @()
$vcenter = "jvcewvvc9702","mvcewvvc9701","astravce9001","dstravce9001","pmplavvc9100"

foreach ($vc in $vcenter){

Connect-VIServer $vc -Credential $credential



Get-DrsVMToVMHostRule | % {
$data = "" | select Vcenter,ClusterName,RuleName,RuleType,Manadatory,Enabled,KeepTogether,VMNames,VmgroupName,AffineHostGroupName,AntiAffineHostGroupName,HostNames
$data.Vcenter = $vc
$data.ClusterName = $_.Cluster
$data.RuleName = $_.Name
$data.RuleType = $_.Type
$data.Manadatory = $_.Mandatory
$data.Enabled = $_.Enabled
$data.VmgroupName = $_.VMGroupName
$data.VMNames = (Get-DrsVMGroup -Name $data.VmgroupName -Cluster $data.ClusterName).VM -join ','
$data.AffineHostGroupName = $_.AffineHostGroupName
$data.AntiAffineHostGroupName = $_.AntiAffineHostGroupName
if ($data.AffineHostGroupName -ne $null){
$data.HostNames = (Get-DrsVMHostGroup -Name $data.AffineHostGroupName -Cluster $data.ClusterName).VMHost -join ','}
if ($data.AntiAffineHostGroupName -ne $null ){
$data.HostNames = (Get-DrsVMHostGroup -Name $data.AntiAffineHostGroupName -Cluster $data.ClusterName).VMHost -join ','
}
cls
$data | fl
$report += $data
#sleep -Seconds 3
}

Get-DrsVMToVMRule | %{
$data = "" | select Vcenter,ClusterName,RuleName,RuleType,Manadatory,Enabled,KeepTogether,VMNames,VmgroupName,AffineHostGroupName,AntiAffineHostGroupName,HostNames
$data.Vcenter = $vc
$data.ClusterName = $_.Cluster
$data.RuleName = $_.Name
$data.RuleType = $_.Type
$data.Manadatory = $_.Mandatory
$data.Enabled = $_.Enabled
$data.KeepTogether = $_.KeepTogether
$data.VMNames = $_.Vm -join ','

$data | fl
$report += $data
}

Write-Host "disconnecting $vc ......." -ForegroundColor Yellow
$global:DefaultVIServers | % {Disconnect-VIServer $_ -Confirm:$false}
}



$Info = "DRSRule Information `n Regards, `n Cloud Ops Team"
$report | Export-Excel -Path $SourceExcel -WorksheetName "DRSRuleDetails" -AutoFilter
$file = Get-ChildItem | where {$_.Name -match "$filename.xlsx"}
Send-MailMessage -To 'Dl-cloud-ops@voya.com' -From "DRSRules@voya.com" -Subject "DRS Rules Inventory $filename" -Attachments $file -Body "Weekly DRSRules Report `n " -SmtpServer smtp1.dsglobal.org
