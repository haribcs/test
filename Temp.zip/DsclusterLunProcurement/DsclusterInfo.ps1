﻿#Import-Module VMware.PowerCLI;
#Connect-VIServer jvcewvvc9702 -user j719374@dsglobal.org -password dsJ03jh9rjmTeIPl
#$clus = Get-DatastoreCluster -Name 'PSHKOMTLCL_SNAPSHOT_REPLICATION_ECR'
$report = @()
$dsclusters = Get-DatastoreCluster | where {$_.ExtensionData.ChildEntity.count -gt 0}
foreach ($clus in $dsclusters ){
$data = "" | select Name,CapacityTB,CapacityOverHead,FreeTB,UseTB,Usepercentage,Reorder,ReOrderPoint,LunsToBeOrdered,vcenter
$data.Name = $clus.Name
$data.CapacityTB = [math]::Round(($clus.CapacityGB /1024),2)
$data.FreeTB = [math]::Round(($clus.FreeSpaceGB/1024),2)
$data.UseTB = $data.CapacityTB - $data.FreeTB
$data.CapacityOverHead = $data.CapacityTB * 0.8
$data.Usepercentage =[math]::Round((($data.UseTB * 100)/$data.CapacityTB),2)
$data.Reorder = $data.CapacityTB * 0.7
$data.ReOrderPoint = $data.Reorder - $data.UseTB
if ($data.ReOrderPoint -lt 0){
$data.LunsToBeOrdered = -([math]::Floor($data.ReOrderPoint /8))
}else{
$data.LunsToBeOrdered = 0

}
$data.vcenter = ($Clus.Uid.Split('@')[1].Split(':')[0]).toupper()
$report += $data
$data | ft -AutoSize


}
$report | Export-Csv .\ds.csv -UseCulture -NoTypeInformation