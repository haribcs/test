﻿Import-Module VMware.PowerCLI | Out-Null
$to = @("SAN Admin <SanAdmin@voya.com>")
$cc = @("DL-Cloud-Ops <DL-Cloud-Ops@voya.com>")
cd D:\CloudOps\RUBilling

$password = Get-Content .\pass.txt | ConvertTo-SecureString -Key (Get-Content .\aes.key)
$credential = New-Object System.Management.Automation.PsCredential("Dsglobal.org\S705979",$password)
$filename = Get-Date -UFormat "%B-%d-%Y"
New-Item -ItemType Directory -Name $filename
cd $filename
Connect-VIServer jvcewvvc9702,mvcewvvc9701 -Credential $credential | Out-Null


Write-Host "Gathering data for set 1" -ForegroundColor Yellow
get-vm | select Name,PowerState,NumCpu,MemoryGB,@{N="UsedSpaceGB";E={[math]::Round($_.UsedSpaceGB,2)}},@{N="ProvisionedSpaceGB";E={[math]::Round($_.ProvisionedSpaceGB,2)}},@{N="GuestDiskUsage"; E={[math]::Round(($_.Guest.Disks | measure -Sum -Property CapacityGB).Sum - ($_.Guest.Disks | measure -Sum -Property FreeSpaceGB).Sum,2)}},@{N="Cluster";E={$_.VMHost.Parent}}, @{ N="vCenter"; E = { $_.Uid.Substring($_.Uid.IndexOf('@')+1).Split(":")[0] }} | Export-Csv -NoTypeInformation .\"VM_Guest_Usage_$filename.csv"

Write-Host "Gathering data for set 2" -ForegroundColor Yellow
get-vm  | %{ $vm=$_; $vm.Guest.Disks | % { $_ | Select path,@{N="VMName";E={$vm.name}},@{N="PowerState";E={$vm.PowerState}},@{N="NumCpu";E={$vm.NumCpu}},@{N="MemoryGB";E={$vm.MemoryGB}},@{N="UsedSpaceGB";E={[math]::Round($vm.UsedSpaceGB,2)}},@{N="ProvisionedSpaceGB";E={[math]::Round($vm.ProvisionedSpaceGB,2)}},@{N="GuestDriveUsage";E={([math]::Round($_.Capacity-$_.FreeSpace,2))/1GB}} ,@{N="Cluster";E={$vm.VMHost.Parent}}, @{ N="vCenter"; E = { $vm.Uid.Substring($vm.Uid.IndexOf('@')+1).Split(":")[0] }}}} | Export-Csv -NoTypeInformation .\"VM_Guest_Usage_Disk_$filename.csv"

$global:DefaultVIServers | %{Disconnect-VIServer $_ -Confirm:$false}

$file = Get-ChildItem
Send-MailMessage -To $to -Cc $cc -From "RuBilling@voya.com" -Subject "RU Billing $filename" -Attachments $file -Body "RU Billing $filename" -SmtpServer smtp1.dsglobal.org
