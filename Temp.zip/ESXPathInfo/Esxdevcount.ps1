﻿$report = @()
foreach($esx in (Get-Cluster "shk*wind*" | Get-VMHost)){

    foreach($hba in (Get-VMHostHba -VMHost $esx -Type "FibreChannel" |where Status -eq Online)){

        $target = ((Get-View $hba.VMhost).Config.StorageDevice.ScsiTopology.Adapter | where {$_.Adapter -eq $hba.Key}).Target

        $luns = Get-ScsiLun -Hba $hba  -LunType "disk" -ErrorAction SilentlyContinue

        $nrPaths = ($target | %{$_.Lun.Count} | Measure-Object -Sum).Sum

 $data = "" | select VMhost,Cluster,HBA,Targets,Devices,Paths
 $data.VMhost = $esx.Name
 $data.Cluster =$esx.Parent
 $data.HBA = $hba.name
 $data.Targets = $target.Count
 $data.Devices= $luns.count
 $data.Paths = $nrPaths

 $data | ft -AutoSize
 $report += $data


        
        

    }

}

$report | Export-Csv .\report12344.csv -UseCulture -NoTypeInformation