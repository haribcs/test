﻿Import-Module VMware.PowerCLI
cd D:\CloudOps\VMFSversion
<#
$password = Get-Content .\pass.txt | ConvertTo-SecureString -Key (Get-Content .\aes.key)
$credential = New-Object System.Management.Automation.PsCredential("Dsglobal.org\S705979",$password)
#>
$filename = get-date -format yyyy-MM-ddTHH-mm-ss

$report = @()
$vcenters = @()
#$vcenters = "Jvcewvvc9702"
#Connect-VIServer "Mvcewvvc9701","Jvcewvvc9702" -Credential $credential 

$version = Get-Datastore | where{ ($_.Type -Match "VMFS") -and ($_.ExtensionData.host.count -gt 1)} | Group-Object -Property FileSystemversion| select Name,count

foreach ($dsclus in Get-DatastoreCluster ){


$data = "" | select Name,NoOfDatastores,NoofVMFS6,Noofvmfs5,CapacityTB,UsedspaceTB,FreespaceTB
$data.Name = $dsclus.Name
$data.NoOfDatastores = $dsclus.ExtensionData.ChildEntity.Count
$data.Noofvmfs5 = ($dsclus |Get-Datastore | where {($_.filesystemversion -LT 6) -and ($_.type -match "vmfs")}).Count
$data.NoofVMFS6 = ($dsclus |Get-Datastore | where {($_.filesystemversion -gT 6) -and ($_.type -match "vmfs")}).Count
$data.CapacityTB = [math]::Round($dsclus.CapacityGB/1024)
$data.FreespaceTB = [math]::Round($dsclus.FreeSpaceGB/1024)
$data.UsedspaceTB =  [math]::Round(($dsclus.CapacityGB - $dsclus.FreeSpaceGB)/1024)
$report += $data
$data | ft -AutoSize

}



# Create a DataTable
$table = New-Object system.Data.DataTable "Filesystemversion"
$col1 = New-Object system.Data.DataColumn Name,([string])
$col2 = New-Object system.Data.DataColumn Count,([string])
$table.columns.add($col1)
$table.columns.add($col2)

for ($i=0;$i -lt $version.Count;$i++){

# Add content to the DataTable
$row = $table.NewRow()
$row.Name = $version[$i].Name
$row.Count = $version[$i].Count
$table.Rows.Add($row)

}

# Create an HTML version of the DataTable
$html = "<table><tr><td>VmfsVersion</td><td>Count</td></tr>"
foreach ($row in $table.Rows)
{ 
    $html += "<tr><td>" + $row[0] + "</td><td>" + $row[1] + "</td></tr>"
}
$html += "</table>"
$body =  $html



$Info = "Daily Vmfs Version Version `n Regards, `n Cloud Ops Team"
$report | Export-Csv -path .\"ComPuteClus-$filename.csv" -UseCulture -NoTypeInformation
$file = Get-ChildItem | where {$_.Name -match "ComPuteClus-$filename.csv"}
Send-MailMessage -To 'dl-cloud-ops@voya.com' -From "DailyVmfsReport@voya.com" -Subject "Daily Vmfs version" -Attachments $file -Body $body -SmtpServer smtp1.dsglobal.org -BodyAsHtml
