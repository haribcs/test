﻿#Import-Module VMware.PowerCLI

Function Format-output {
   param (
      [Parameter(Mandatory=$true)][string]$Text,
      [Parameter(Mandatory=$true)][string]$Level,
      [Parameter(Mandatory=$false)][string]$Phase
   )

   BEGIN {
      filter timestamp {"$(Get-Date -Format s) `[$Phase`] $Text" }
   }

   PROCESS {
      $Text | timestamp | Out-File -FilePath $global:LogFile -Append -Force
      if($Level -eq "SUCCESS" ) {
         $Text | timestamp | format-output -foregroundcolor "green"
      } elseif ( $Level -eq "INFO") {
         $Text | timestamp | Write-Host  -foregroundcolor "Yellow"
      } else {
         $Text | timestamp | format-output -foregroundcolor "red"
      }
   }
}

$Name = Read-Host -Prompt "Please provide the Datastore cluster name"


$LogTime = Get-Date -Format "MM-dd-yyyy_hh-mm-ss"
$workingDirectory = pwd
$logFileName = "Datastore_Upgrade_"+ $Name + $LogTime + ".log"
$global:LogFile = Join-Path $workingDirectory $logFileName

if (Get-DatastoreCluster $Name -ErrorAction SilentlyContinue){
$dsCluster = Get-DatastoreCluster -Name $Name
$clus =  Get-View -ViewType StoragePod -Filter @{"Name"=$Name}
$pod = New-Object VMware.Vim.ManagedObjectReference
$pod.Type = 'StoragePod'
$pod.Value = $clus.MoRef.Value
Format-output "Checking Any vm overrides on the $Name" -Level info -Phase "SDRS Cluster-Override"

$spec = New-Object VMware.Vim.StorageDrsConfigSpec
$spec.VmConfigSpec = New-Object VMware.Vim.StorageDrsVmConfigSpec[] ($clus.PodStorageDrsEntry.StorageDrsConfig.VmConfig.Count)


for ($i=0; $i -lt $Clus.PodStorageDrsEntry.StorageDrsConfig.VmConfig.count;$i++){
$spec.VmConfigSpec[$i] = New-Object VMware.Vim.StorageDrsVmConfigSpec
$spec.VmConfigSpec[$i].Operation = 'add'
$spec.VmConfigSpec[$i].Info = New-Object VMware.Vim.StorageDrsVmConfigInfo
$spec.VmConfigSpec[$i].Info.Vm = New-Object VMware.Vim.ManagedObjectReference
$spec.VmConfigSpec[$i].Info.Vm.Type = 'VirtualMachine'
$spec.VmConfigSpec[$i].Info.Vm.Value = $clus.PodStorageDrsEntry.StorageDrsConfig.VmConfig.Vm[$i].value

}
$modify = $true
$_this = Get-View -Id 'StorageResourceManager-StorageResourceManager'
$_this.ConfigureStorageDrsForPod_Task($pod, $spec, $modify)
Format-output "Completed vm overrides on the $Name" -Level info -Phase "SDRS Cluster-Override"

Format-output -text "$dsCluster has found in the VcenterStarting the vmfs upgrade on the list" -Level info -Phase "Initial"


$vmfs5Ds = Get-Datastore -Id ($dsCluster.ExtensionData.ChildEntity) | where filesystemversion -lt 6
format-output "Found $($vmfs5Ds.count) vmfs5 Datastores in $dsCluster Cluster" -level info -Phase "info"


foreach ($datastore in $vmfs5Ds){


$Template = $datastore | Get-Template
If($Template -ne $null){
$Template | Set-Template -ToVM -Confirm:$false

}
if (($datastore | Get-Template).count -gt 0){}
format-output "Started working on the $datastore" -Level info -Phase "Start"
$Esxhosts = $datastore | Get-VMHost
$lun = $datastore.ExtensionData.Info.Vmfs.Extent.diskname.ToLower()
$Dsname = $datastore.Name
#sleep -Seconds 5
#Stage1 Convert Template to VM
#Stage2  Place Datastore in Maintenance Mode so all vm can move
format-output "Keeping the $datastore in Maintenance" -Level info -Phase "info"
Set-Datastore -Datastore $datastore -MaintenanceMode $true -EvacuateAutomatically -Confirm:$false
format-output "$datastore in Maintenance" -Level info -Phase "info"
do{
write-host "Sleeping for 10 Seconds" -ForegroundColor Yellow
#$datastore.State
sleep -Seconds 10

}while( (Get-Datastore $datastore).state -ne "Maintenance")

#Stage3 UnmountDatastore

#Stage4 Copy Orphaned File
#stage5 Remove Datastore

$ds =  New-Object VMware.Vim.ManagedObjectReference
$ds.Type = $datastore.ExtensionData.MoRef.type
$ds.Value = $datastore.ExtensionData.MoRef.value

$esx = $datastore.ExtensionData.Host.key.Value | Get-Random
$id = "HostDatastoreSystem-datastoreSystem-" + $esx.Split('-')[1]
$Hostview =  Get-View -Id $id
Format-output "Removing $datastore" -Level info -Phase "Remove Datastore"
$Hostview.RemoveDatastore($ds)
Format-output "Sleeping for 45 seconds" -Level info -Phase "Sleep"
sleep -seconds 60
#Stage6 Create datastore
do {
Write-Host "Waiting for $datastore to be removed; Sleeping for 10 Seconds"
sleep -Seconds 10

}while((Get-Datastore -Name $Dsname -ErrorAction SilentlyContinue) -ne $null)

Format-output "creating datastore" -Level info -Phase 'create vmfs6'
New-Datastore -Name $Dsname -VMHost ($Esxhosts | Get-Random) -Path $lun -Vmfs -FileSystemVersion 6
Format-output "created datastore successfully" -Level info -Phase 'created vmfs6'
sleep -Seconds 15
if ((Get-Datastore $Dsname).ExtensionData.Host.Count -lt $Esxhosts.count ){
#Format-output "Scanning $($Esxhosts.count) Esxi hosts" -Level info -Phase 'Scan Esxi'
$missingHost = (Compare-Object -ReferenceObject $Esxhosts -DifferenceObject (Get-Datastore -Name $Dsname | Get-VMHost)).InputObject
 $vc = $global:DefaultVIServer
 $missingHost | foreach -Parallel {  Get-VMHostStorage -VMHost $_ -RescanVmfs -Server $vc.Name | Out-Null}
Format-output "Scan completed $($missingHost.count) Esxi hosts" -Level info -Phase 'Scaned Esxi'
}
#Stage7 Move Datastore to Cluster

Format-output "Moving $datastore vmfs 6 to $dsCluster "-Level info -Phase "Final"
Get-Datastore $datastore.Name | Move-Datastore -Destination $dsCluster -Confirm:$false
Format-output "vmfs 6 has completed for  $dsCluster "-Level info -Phase "Finish"
if ($Template -ne $null){
$dsCluster | Get-VM $Template.Name | Set-VM -ToTemplate -Confirm:$false | Out-Null}


}


}else
{  Write-Host "DatastoreCluster $Name is not found, Please verify and run the script again.  Terminating the script............." -ForegroundColor Red   
break;
}