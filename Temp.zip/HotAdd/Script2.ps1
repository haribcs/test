﻿
$tgtFolder = "D:\CloudOps\HotAdd"
#cd D:\CloudOps\HotAdd
#Import-Module VMware.PowerCLI

$vms =   Get-VM | where powerstate -eq PoweredOn


foreach ($vm in $vms) {
  #$dsName,$vmxPath = $vm.ExtensionData.Config.Files.VmPathName.Split('] ')
  $dsName = $vm.ExtensionData.Config.Files.VmPathName.Split(']')[0].split('[')[1]
  $vmxPath =$vm.ExtensionData.Config.Files.VmPathName.Split(']')[1].split(' ')[1]
  Write-Host "$dsName" -ForegroundColor Yellow
  #sleep -Seconds 30
  Write-Host "Working on $dsName and $vmxPath" -ForegroundColor Yellow
  
 
  #$dsName = $dsName.Trim('[')
  Write-Host "$dsName"
  $ds = Get-Datastore -Name "$dsName"

  $ds 
  #sleep -Seconds 30
  New-PSDrive -Location $ds -Name DS -PSProvider VimDatastore -Root "\" | Out-Null
  Copy-DatastoreItem -Item "DS:$vmxPath" -Destination $tgtFolder
  Remove-PSDrive -Name DS -Confirm:$false
}