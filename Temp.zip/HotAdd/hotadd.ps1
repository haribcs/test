﻿
Function Enable-vCpuAndMemHotAdd($vm){ 

  $vmConfigSpec = New-Object VMware.Vim.VirtualMachineConfigSpec 

  $extra1 = New-Object VMware.Vim.optionvalue 

  $extra1.Key="mem.hotadd" 

  $extra1.Value="true" 

  $vmConfigSpec.extraconfig += $extra1 

  $extra2 = New-Object VMware.Vim.optionvalue 

  $extra2.Key="vcpu.hotadd" 

  $extra2.Value="true" 

  $vmConfigSpec.extraconfig += $extra2 

  $vm.Extensiondata.ReconfigVM($vmConfigSpec) 

} 
<#
Function​​ Enable-MemHotAdd($vm){

   ​​ $vmview​​ =​​ Get-vm​​ $vm​​ |​​ Get-View

   ​​ $vmConfigSpec​​ =​​ New-Object​​ VMware.Vim.VirtualMachineConfigSpec

   ​​ $extra​​ =​​ New-Object​​ VMware.Vim.optionvalue

   ​​ $extra.Key="mem.hotadd"

   ​​ $extra.Value="true"

   ​​ $vmConfigSpec.extraconfig​​ +=​​ $extra

   ​​ $vmview.ReconfigVM($vmConfigSpec)

}



Function​​ Enable-vCpuHotAdd($vm){

   ​​ $vmview​​ =​​ Get-vm​​ $vm​​ |​​ Get-View

   ​​ $vmConfigSpec​​ =​​ New-Object​​ VMware.Vim.VirtualMachineConfigSpec

   ​​ $extra​​ =​​ New-Object​​ VMware.Vim.optionvalue

   ​​ $extra.Key="vcpu.hotadd"

   ​​ $extra.Value="true"

   ​​ $vmConfigSpec.extraconfig​​ +=​​ $extra

   ​​ $vmview.ReconfigVM($vmConfigSpec)

}
#>

$report = @()
cd D:\CloudOps\HotAdd
#Import-Module VMware.PowerCLI

foreach ($vm in (Get-VM)){
if (($vm.name.Substring(4,1) -eq 'l') -or ($vm.name.Substring(4,1) -eq 'w')){

if (($vm.ExtensionData.Config.MemoryHotAddEnabled -match "False") -or ($vm.ExtensionData.Config.CpuHotAddEnabled -match "false")){
$data = "" | select Name,powerstatus,HotAdd,HotPlug,vcenter
$data.Name = $vm.Name
$data.powerstatus = $vm.PowerState
$data.HotAdd = $vm.ExtensionData.Config.MemoryHotAddEnabled
$data.HotPlug = $vm.ExtensionData.Config.CpuHotAddEnabled
$data.vcenter =  $vm.Uid.Split('@')[1].split(':')[0]
$data | ft -AutoSize
$report += $data
Enable-vCpuAndMemHotAdd $vm.name
}


}
}


$report | Export-Csv .\new-report.csv -UseCulture -NoTypeInformation


#Enable-vCpuAndMemHotAdd -vm 