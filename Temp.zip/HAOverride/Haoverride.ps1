﻿$modify = $true
foreach ($Clus in ( Get-View -ViewType ComputeResource)){
If ($Clus.ConfigurationEx.DasVmConfig.count -gt 0){
Write-Host "cluster name is "$Clus.name

$spec = New-Object VMware.Vim.ClusterConfigSpecEx
$spec.DasVmConfigSpec = New-Object VMware.Vim.ClusterDasVmConfigSpec[] ($Clus.ConfigurationEx.DasVmConfig.count)

for ($i=0; $i -lt $Clus.ConfigurationEx.DasVmConfig.count;$i++){

Write-Host "Removing " $i "from" $Clus.ConfigurationEx.DasVmConfig.count
$spec.DasVmConfigSpec[$i] = New-Object VMware.Vim.ClusterDasVmConfigSpec
$spec.DasVmConfigSpec[$i].RemoveKey = New-Object VMware.Vim.ManagedObjectReference
$spec.DasVmConfigSpec[$i].RemoveKey.Type = 'VirtualMachine'
$spec.DasVmConfigSpec[$i].RemoveKey.Value = $Clus.ConfigurationEx.DasVmConfig[$i].Key.value
$spec.DasVmConfigSpec[$i].Operation = 'remove'
}
$Clus.ReconfigureComputeResource_Task($spec, $modify)
}
cls

}