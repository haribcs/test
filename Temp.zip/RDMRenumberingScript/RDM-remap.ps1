﻿$disks = Import-Csv .\phase2.csv
foreach ($disk in $disks){
#$disk

$spec = New-Object VMware.Vim.VirtualMachineConfigSpec
$spec.DeviceChange = New-Object VMware.Vim.VirtualDeviceConfigSpec[] (1)
$spec.DeviceChange[0] = New-Object VMware.Vim.VirtualDeviceConfigSpec
$spec.DeviceChange[0].FileOperation = 'create'
$spec.DeviceChange[0].Device = New-Object VMware.Vim.VirtualDisk
$spec.DeviceChange[0].Device.CapacityInBytes = $disk.CapacityInBytes
$spec.DeviceChange[0].Device.StorageIOAllocation = New-Object VMware.Vim.StorageIOAllocationInfo
$spec.DeviceChange[0].Device.StorageIOAllocation.Shares = New-Object VMware.Vim.SharesInfo
$spec.DeviceChange[0].Device.StorageIOAllocation.Shares.Shares = 1000
$spec.DeviceChange[0].Device.StorageIOAllocation.Shares.Level = 'normal'
$spec.DeviceChange[0].Device.StorageIOAllocation.Limit = -1
$spec.DeviceChange[0].Device.Backing = New-Object VMware.Vim.VirtualDiskRawDiskMappingVer1BackingInfo
$spec.DeviceChange[0].Device.Backing.CompatibilityMode = 'physicalMode'
$spec.DeviceChange[0].Device.Backing.FileName = $disk.FileName
$spec.DeviceChange[0].Device.Backing.Datastore = New-Object VMware.Vim.ManagedObjectReference
$spec.DeviceChange[0].Device.Backing.Datastore.Type = 'Datastore'
$spec.DeviceChange[0].Device.Backing.Datastore.Value = $disk.DatastoreValue
$spec.DeviceChange[0].Device.Backing.DiskMode = 'independent_persistent'
$spec.DeviceChange[0].Device.Backing.DeviceName = $disk.DeviceName
$spec.DeviceChange[0].Device.ControllerKey = $disk.ControllerKey
$spec.DeviceChange[0].Device.UnitNumber = $disk.UnitNumber
$spec.DeviceChange[0].Device.CapacityInKB = $disk.CapacityInKB
$spec.DeviceChange[0].Device.DeviceInfo = New-Object VMware.Vim.Description
$spec.DeviceChange[0].Device.DeviceInfo.Summary = 'New Hard disk'
$spec.DeviceChange[0].Device.DeviceInfo.Label = 'New Hard disk'
$spec.DeviceChange[0].Device.Key = -101
$spec.DeviceChange[0].Operation = 'add'
$spec.CpuFeatureMask = New-Object VMware.Vim.VirtualMachineCpuIdInfoSpec[] (0)
$_this = Get-View -Id $disk.vmid
$_this.ReconfigVM_Task($spec)
Write-Host "Completed "$disk.Name "for "$disk.VMname
sleep -Seconds 5
}