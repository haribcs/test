﻿$report = @()
#$disks = Get-Cluster "STR DB2 CLUSTER" | Get-VM | Get-HardDisk -DiskType RawPhysical,RawVirtual
foreach ($disk in (Get-VM (Get-Content C:\Users\j719374\Desktop\Vms.txt)| Get-HardDisk -DiskType RawPhysical,RawVirtual)){

$info = "" | select VMname,Name,CapacityInBytes,CapacityInKB,FileName,DatastoreValue,DeviceName,ControllerKey,UnitNumber,vmid
$info.CapacityInBytes = $disk.ExtensionData.CapacityInBytes
$info.CapacityInKB = $disk.CapacityKB
$info.FileName = $disk.ExtensionData.Backing.FileName.Split(' ')[0]
$info.DatastoreValue = $disk.ExtensionData.Backing.Datastore.Value
$info.DeviceName = "/vmfs/devices/disks/"+$disk.ScsiCanonicalName
$info.ControllerKey = $disk.ExtensionData.ControllerKey
$info.UnitNumber = $disk.ExtensionData.UnitNumber
$info.vmid = $disk.ParentId
$info.vmname = $disk.Parent
$info.Name = $disk.Name
$report += $info
$info | select *
#Sleep -Seconds 10
}
$report | Export-Csv .\phase2.csv -UseCulture -NoTypeInformation
