﻿connect-viserver mvcewvvc9701,jvcewvvc9702 -user administrator@vsphere.local -password VMwar3!!VMwar3!!
cd 'D:\CloudOps\QlogicHBA&NicDriverVersion'
$filename = get-date -format yyyy-MM-ddTHH-mm-ss
$report = @()
foreach ($esx in (Get-VMHost)){
$data  = "" | select Esxi,Cluster,NiCDriver,HBADriver,vcenter
$data.Esxi = $esx.name
$data.Cluster = $esx.Parent.Name
$data.vcenter = $esx.Uid.Split('@')[1].split(':')[0]
$esxcli = Get-EsxCli -VMHost $esx
$temp = $esxcli.software.vib.list()
$data.HBADriver = ($temp | where name -Match "qlnativefc").version
$data.NiCDriver = ($temp | where name -Match "qedentv").version
$data | ft -AutoSize
$report += $data
}
$report | Export-Csv -Path .\"HBANic-$filename.csv" -UseCulture -NoTypeInformation
Disconnect-VIServer -Server mvcewvvc9701,jvcewvvc9702 -Confirm:$false -Force