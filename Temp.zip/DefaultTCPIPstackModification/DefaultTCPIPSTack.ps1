#$esxName = 'esx1.local.homelab'
$stackName = 'defaultTcpipStack'
$domainName = 'dsglobal.org'
$esx = Get-VMHost -Name pstresx129*
$netSys = Get-View -Id $esx.ExtensionData.ConfigManager.NetworkSystem
$stack = $esx.ExtensionData.Config.Network.NetStackInstance | where{$_.Key -eq $stackName}
$config = New-Object VMware.Vim.HostNetworkConfig

$spec = New-Object VMware.Vim.HostNetworkConfigNetStackSpec

$spec.Operation = [VMware.Vim.ConfigSpecOperation]::edit

$spec.NetStackInstance = $stack

#$spec.NetStackInstance.RouteTableConfig = New-Object VMware.Vim.HostIpRouteTableConfig

$dns = New-Object VMware.Vim.HostDnsConfig
#$dns.Address = $dnsServers
#$dns.Dhcp = $false
#$dns.HostName = $hostName
$dns.DomainName = $domainName
$dns.SearchDomain = $domainName
$spec.NetStackInstance.DnsConfig = $dns
$config.NetStackSpec += $spec
$netsys.UpdateNetworkConfig($config,[VMware.Vim.HostConfigChangeMode]::modify)