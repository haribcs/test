Connect-VIServer cdcrs422 -User jn5840 -Password Indiacsc@1113
$allstats = @()
$hosts = Get-VMHost

foreach($vmHost in $hosts){

  $statcpu = Get-Stat -Entity ($vmHost) -start (get-date).AddDays(-34) -Finish (Get-Date).AddDays(-6) -MaxSamples 10000 -stat mem.usage.average
foreach($statentry in $statcpu){
  $hoststat = "" | Select HostName, memusage, Timestamp
  Write-Host $statentry.Value -foregroundcolor red -backgroundcolor yellow
  $hoststat.memusage = $statentry.Value
  $hoststat.Timestamp = $statentry.Timestamp
  $hoststat.HostName = $vmHost.name
  $allstats += $hoststat
}
$allstats | Select HostName, Timestamp, memusage | Export-Csv ".\na-memusage.csv" -noTypeInformation
}